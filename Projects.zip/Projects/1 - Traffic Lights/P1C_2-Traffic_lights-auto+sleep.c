/************************************************************************
*                                                                       *
*   Filename:      P1C_2-Traffic_lights-auto+sleep.c                    *
*   Date:          23/6/13                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Baseline PIC                                         *
*   Processor:     10F200                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-XC8.h     (provides DbnceHi macro)        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Simple Traffic Lights                               *
*                   Tutorial project 1, example 2                       *
*                                                                       *
*   Lights green, yellow and red lights in sequence                     *
*   (timing defined by program constants)                               *
*   Enters standby mode on pushbutton press,                            *
*   then wakes on subsequent press                                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       GP0 = green  light (LED), active high                           *
*       GP1 = yellow light (LED), active high                           *
*       GP2 = red    light (LED), active high                           *
*       GP3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#include "stdmacros-XC8.h"  // DbnceHi() - debounce switch, wait for high
                            // Requires: TMR0 at 256 us/tick

/***** CONFIGURATION *****/
// int reset, no code protect, no watchdog
#pragma config MCLRE = OFF, CP = OFF, WDTE = OFF

// oscillator frequency for __delay_ms()
#define _XTAL_FREQ  4000000     

// Pin assignments
#define LEDS    GPIO                // all LEDs
#define G_LED   GPIObits.GP0        // individual LEDs
#define Y_LED   GPIObits.GP1
#define R_LED   GPIObits.GP2
#define BUTTON  GPIObits.GP3        // Pushbutton (active low)


/***** CONSTANTS *****/
#define G_TIME  12                  // time (seconds) each colour is turned on for
#define Y_TIME   3
#define R_TIME  10

#define G_START 0                   // seconds into cycle to turn on each LED
#define Y_START G_TIME
#define R_START Y_START + Y_TIME

#define R_END   R_START + R_TIME    // total cycle length

#define POLL_MS 50                  // polling interval (in ms)


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t sec_cnt;            // seconds counter
    uint8_t p_cnt;              // polling loop counter
    
    //*** Initialisation
    
    // configure ports
    GPIO = 0b0000;              // start with all LEDs off
    TRIS = 0b1000;              // configure LED pins (GP0-2) as outputs

    // configure wake-on-change, pull-ups and timer
    OPTION = 0b00000111;        // configure wake-up on change and Timer0:
             //0-------             enable wake-up on change (/GPWU = 0)
             //-0------             enable weak pull-ups (/GPPU = 0)
             //--0-----             timer mode (T0CS = 0)
             //----0---             prescaler assigned to Timer0 (PSA = 0)
             //-----111             prescale = 256 (PS = 111)
             //                     -> increment every 256 us
             //                        GP2 usable as an output

    // wait for stable button release
    // (in case it is still bouncing following wake-up on change)
    DbnceHi(BUTTON); 
    

    //*** Main loop
    for (;;)
    {
        // light each LED in sequence
        for (sec_cnt = 0; sec_cnt < R_END; sec_cnt++)
        {
            // light appropriate LED, depending on elapsed time
            if (sec_cnt == G_START)
            {
                LEDS = 0;               // turn off all LEDs
                G_LED = 1;              // turn on green LED
            }
            if (sec_cnt == Y_START)
            {
                LEDS = 0;               // turn off all LEDs  
                Y_LED = 1;              // turn on yellow LED
            }
            if (sec_cnt == R_START)
            {
                LEDS = 0;               // turn off all LEDs  
                R_LED = 1;              // turn on red LED
            }

            // delay 1 second while polling pushbutton
            // (repeat 1000/POLL_MS times)
            for (p_cnt = 0; p_cnt < 1000/POLL_MS; p_cnt++)  
            {
                __delay_ms(POLL_MS);    // polling interval
            
                // check for button press
                if (!BUTTON)
                {
                    // go into standby (low power) mode
                    LEDS = 0;           // turn off all LEDs
                    DbnceHi(BUTTON);    // wait for stable button release
                    SLEEP();            // enter sleep mode
                }
            }
        }        
    }                               // repeat forever
}
