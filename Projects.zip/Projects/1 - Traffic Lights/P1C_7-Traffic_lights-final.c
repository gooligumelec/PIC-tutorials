/************************************************************************
*                                                                       *
*   Filename:      P1C_7-Traffic_lights-final.c                         *
*   Date:          31/8/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Baseline PIC                                         *
*   Processor:     12F508/509                                           *
*   Compiler:      MPLAB XC8 v1.20 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-XC8.h     (provides DbnceHi macro)        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Simple Traffic Lights                               *
*                   Tutorial project 1, example 7                       *
*                   (final production version)                          *
*                                                                       *
*   Automatic or manual operation, selected by slide switch             *
*                                                                       *
*   Automatic mode:                                                     *
*       Sequence G->Y->R->G based on preset times                       *
*       Power down (standby) on button press                            *
*                                                                       *
*   Manual mode:                                                        *
*       G->Y, Y->R, R->G transitions on button press                    *
*                                                                       *
*   Mode can be changed through select switch at any time               *  
*                                                                       *
*   Power on (wake from standby) on button press                        *
*                                                                       *
*   Power off (standby) on button press in automatic modes,             *
*   or if no button press or switch change                              *
*   during timeout period (60 mins)                                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       GP0 = green  light (LED), active low                            *
*       GP4 = yellow light (LED), active low                            *
*       GP5 = red    light (LED), active low                            *
*       GP1 = pushbutton switch (active low)                            *
*       GP2 = slide switch (low = auto, high = manual mode)             *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#include "stdmacros-XC8.h"  // DbnceHi() - debounce switch, wait for high
                            // Requires: TMR0 at 256 us/tick

/***** CONFIGURATION *****/
// int reset, no code protect, no watchdog, int RC oscillator
#pragma config MCLRE = OFF, CP = OFF, WDT = OFF, OSC = IntRC

// oscillator frequency for __delay_ms()
#define _XTAL_FREQ  4000000     

// Pin assignments
#define LEDS    GPIO                // all LEDs
#define G_LED   GPIObits.GP0        // individual LEDs
#define Y_LED   GPIObits.GP4
#define R_LED   GPIObits.GP5
#define BUTTON  GPIObits.GP1        // pushbutton (active low)
#define SELECT  GPIObits.GP2        // mode switch:
#define SEL_auto    0               //  low = auto
#define SEL_manual  1               //  high = manual


/***** CONSTANTS *****/
#define G_TIME  12                  // time (seconds) each colour is turned on for
#define Y_TIME   3
#define R_TIME  10

#define G_START 0                   // seconds into cycle to turn on each LED
#define Y_START G_TIME
#define R_START Y_START + Y_TIME

#define R_END   R_START + R_TIME    // total cycle length

#define POLL_MS 50                  // polling interval (in ms)
#define TIMEOUT 60                  // auto-off timeout (in minutes)


/***** PROTOTYPES *****/
void AutoMode(void);                // automatic mode
void ManualMode(void);              // manual mode
void standby(void);                 // enter standby (low-power) mode


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure ports
    GPIO = 0b111111;            // start with all LEDs off
    TRIS = 0b001110;            // configure LED pins (GP0,4,5) as outputs

    // configure wake-on-change, pull-ups and timer
    OPTION = 0b00000111;        // configure wake-up on change and Timer0:
             //0-------             enable wake-up on change (/GPWU = 0)
             //-0------             enable weak pull-ups (/GPPU = 0)
             //--0-----             timer mode (T0CS = 0)
             //----0---             prescaler assigned to Timer0 (PSA = 0)
             //-----111             prescale = 256 (PS = 111)
             //                     -> increment every 256 us
             //                        GP2 usable as an output
             
    // wait for stable button release
    // (in case it is still bouncing following wake-up on change)
    DbnceHi(BUTTON); 


    //*** Main loop
    for (;;)
    {
        // enter appropriate mode, depending on select switch
        if (SELECT == SEL_auto)     
            AutoMode();            
        else
            ManualMode();        
    }  
}


/***** FUNCTIONS *****/

/***** Automatic mode *****/
void AutoMode(void)
{
    uint8_t     sec_cnt;            // seconds counter (for LED sequencing)
    uint16_t    time_cnt = 0;       // timeout counter (seconds since reset) 
    uint8_t     p_cnt;              // polling loop counter
    
    for (;;)
    {
        // light each LED in sequence
        for (sec_cnt = 0; sec_cnt < R_END; sec_cnt++)
        {
            // light appropriate LED, depending on elapsed time
            if (sec_cnt == G_START)
            {
                LEDS = 0b111111;        // turn off all LEDs
                G_LED = 0;              // turn on green LED
            }
            if (sec_cnt == Y_START)
            {
                LEDS = 0b111111;        // turn off all LEDs  
                Y_LED = 0;              // turn on yellow LED
            }
            if (sec_cnt == R_START)
            {
                LEDS = 0b111111;        // turn off all LEDs  
                R_LED = 0;              // turn on red LED
            }

            // delay 1 second while polling pushbutton
            // (repeat 1000/POLL_MS times)
            for (p_cnt = 0; p_cnt < 1000/POLL_MS; p_cnt++)  
            {
                __delay_ms(POLL_MS);    // polling interval
            
                // check for button press
                if (!BUTTON)
                    standby();          // enter standby mode
                
                // check for mode change
                if (SELECT == SEL_manual)
                    return;             // exit automatic mode
            }
            
            // check for timeout
            if (++time_cnt == TIMEOUT*60)
                standby();          // enter standby mode
        }        
    } 
}


/***** Manual mode *****/
void ManualMode(void)
{
    enum {GREEN, YELLOW, RED} state;    // state = currently-lit LED
    
    uint16_t    time_cnt = 0;       // timeout counter (seconds since reset)
    uint8_t     p_cnt;              // polling loop counter    
    
    // set initial state
    state = GREEN;              // initial state is green, so
    LEDS = 0b111111;
    G_LED = 0;                  // turn on green LED (only)
    
    for (;;)
    {
        // delay 1 second while polling pushbutton
        // (repeat 1000/POLL_MS times)
        for (p_cnt = 0; p_cnt < 1000/POLL_MS; p_cnt++)  
        {
            __delay_ms(POLL_MS);    // polling interval
        
            // check for button press
            if (!BUTTON)            // if button pressed
            {
                time_cnt = 0;           // reset timeout counter
                
                // light next LED in sequence
                LEDS = 0b111111;        // turn off all LEDs
        
                switch (state)          // next LED depends on currently-lit LED
                {
                    case GREEN:             // if green:
                        state = YELLOW;     //  next state = yellow
                        Y_LED = 0;          //  turn on yellow LED     
                        break;
                
                    case YELLOW:            // if yellow:
                        state = RED;        //  next state = red
                        R_LED = 0;          //  turn on red LED  
                        break;
               
                    case RED:               // if red:
                        state = GREEN;      //  next state = green
                        G_LED = 0;          //  turn on green LED
                        break;
                }
                // wait for stable button release
                DbnceHi(BUTTON);
            }
            
            // check for mode change
            if (SELECT == SEL_auto)
                return;                 // exit manual mode
        }
            
        // check for timeout
        if (++time_cnt == TIMEOUT*60)
            standby();          // enter standby mode
    }                     
}


/***** Enter standby (low power) mode *****/
void standby(void)
{
    LEDS = 0b111111;    // turn off all LEDs
    DbnceHi(BUTTON);    // wait for stable button release
    SLEEP();            // enter sleep mode    
}
