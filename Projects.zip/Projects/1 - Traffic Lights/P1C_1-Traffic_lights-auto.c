/************************************************************************
*                                                                       *
*   Filename:      P1C_1-Traffic_lights-auto.c                          *
*   Date:          11/6/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Baseline PIC                                         *
*   Processor:     10F200                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Simple Traffic Lights                               *
*                   Tutorial project 1, example 1                       *
*                                                                       *
*   Lights green, yellow and red lights in sequence                     *
*   (timing defined by program constants)                               *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       GP0 = green  light (LED), active high                           *
*       GP1 = yellow light (LED), active high                           *
*       GP2 = red    light (LED), active high                           *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
// ext reset, no code protect, no watchdog
#pragma config MCLRE = ON, CP = OFF, WDTE = OFF

// oscillator frequency for __delay_ms()
#define _XTAL_FREQ  4000000     

// Pin assignments
#define G_LED   GPIObits.GP0        // LEDs
#define Y_LED   GPIObits.GP1
#define R_LED   GPIObits.GP2


/***** CONSTANTS *****/
#define G_TIME  12              // time (seconds) each colour is turned on for
#define Y_TIME   3
#define R_TIME  10


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure ports
    GPIO = 0b0000;          // start with all LEDs off
    TRIS = 0b1000;          // configure LED pins (GP0-2) as outputs

    // configure timer
    OPTION = 0b11011111;            // configure Timer0:
             //--0-----                 timer mode (T0CS = 0)
             //                         -> GP2 usable as an output


    //*** Main loop
    for (;;)
    {
        // light each LED in sequence
        G_LED = 1;                  // turn on green LED
        __delay_ms(G_TIME*1000);    //  for green "on" time
        G_LED = 0;
        
        Y_LED = 1;                  // turn on yellow LED
        __delay_ms(Y_TIME*1000);    //  for yellow "on" time
        Y_LED = 0;
        
        R_LED = 1;                  // turn on red LED
        __delay_ms(R_TIME*1000);    //  for red "on" time
        R_LED = 0;
        
    }                               // repeat forever
}
