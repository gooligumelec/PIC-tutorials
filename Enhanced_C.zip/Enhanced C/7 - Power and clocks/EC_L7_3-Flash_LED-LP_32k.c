/************************************************************************
*                                                                       *
*   Filename:      EC_L7_3-Flash_LED-LP_32k.c                           *
*   Date:          5/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 3                                 *
*                                                                       *
*   Demonstrates use of LP oscillator mode                              *
*   (using 32.768 kHz crystal)                                          *
*                                                                       *
*   LED flashes at 1 Hz (50% duty cycle),                               *
*   with timing derived from 8192 Hz instruction clock                  *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC1         = flashing LED                                      *
*       OSC1, OSC2  = 32.768 kHz crystal                                *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, LP oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = LP, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define FLASH  LATCbits.LATC1       // flashing LED


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure port   
    LATC = 0;                       // start with all output pins low (LED off)     
    TRISC = 0b111101;               // configure RC1 (only) as an output
    
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b100;      // prescale = 32
                                    // -> increment at 256 Hz with 8192 Hz inst clock
                                    
                 
    /*** Main loop ***/
    for (;;)
    {
        // TMR0<7> cycles at 1 Hz, so continually copy to LED
        FLASH = (TMR0 & 1<<7) != 0;     // FLASH = TMR0<7>
    } 
}
