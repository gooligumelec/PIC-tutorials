/************************************************************************
*                                                                       *
*   Filename:      EC_L7_1b-Flash_LED-IntRC_32M+PLL.c                   *
*   Date:          5/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 1b                                *
*                                                                       *
*   Demonstrates enabling 4xPLL via processor config                    *
*                                                                       *
*   Flashes an LED at approx 4 Hz                                       *
*   using internal 8 MHz RC oscillator + 4xPLL                          *
*                                                                       *
*   4xPLL is also enabled via software whenever pushbutton is pressed   *
*   (this has no effect because processor config has higher priority)   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC1 = indicator LED                                             *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  8000000     // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), 4xPLL on
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = ON
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define FLASH   LATCbits.LATC1      // flashing LED
#define BUTTON  PORTAbits.RA3       // pushbutton (active low)


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATC = 0;                   // start with all output pins low (LED off)
    TRISC = 0b111101;           // configure RC1 (only) as an output
    
    // configure oscillator
    OSCCONbits.SCS = 0b00;      // clock source = config word (= INTOSC)
    OSCCONbits.IRCF = 0b1110;   // internal oscillator = 8 MHz
                                // -> 32 MHz processor clock (4xPLL enabled)

    
    /*** Main loop ***/
    for (;;)  
    {       
        // enable 4xPLL only if button pressed
        // (has no effect due to 4xPLL being enabled in processor config)
        OSCCONbits.SPLLEN = ~BUTTON;    // SPLLEN = 1 only if button pressed
        
        // delay 125 ms -> 4 Hz flashing at 50% duty cycle
        __delay_ms(500);        // (500 ms at 8 MHz -> 125 ms at 32 MHz)
             
        // toggle LED
        FLASH = ~FLASH;        
    }
}
