/************************************************************************
*                                                                       *
*   Filename:      EC_L7_6-ExtRC+CLKR.c                                 *
*   Date:          6/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 6                                 *
*                                                                       *
*   Demonstrates reference clock external output                        *
*                                                                       *
*   LED on CLKR pin flashes at 1/128 clock freq (25% duty cycle),       *
*   with processor clock derived from external RC oscillator            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CLKR = flashing LED                                             *
*       OSC1 = R (10k) / C (182n) -> ~1 kHz                             *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, ext RC oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = EXTRC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/

    // configure reference clock
    CLKRCONbits.CLKRDIV = 0b111;    // clock divider = 128
    CLKRCONbits.CLKRDC = 0b01;      // 25% duty cycle
    CLKRCONbits.CLKRSLR = 0;        // no slew rate limiting
    CLKRCONbits.CLKREN = 1;         // enable module
    CLKRCONbits.CLKROE = 1;         // enable CLKR pin output
                                    //  -> output Fosc/128 (25% duty) on CLKR
                                    //  -> flash LED at ~8 Hz (if ~1 kHz clock)
                
    /*** Main loop ***/
    for (;;)
    {
        ;   // (do nothing)
    } 
}
