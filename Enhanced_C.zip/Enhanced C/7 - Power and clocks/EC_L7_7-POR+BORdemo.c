/************************************************************************
*                                                                       *
*   Filename:      EC_L7_7-POR+BODdemo.c                                *
*   Date:          6/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 7                                 *
*                                                                       *
*   Demonstrates use of brown-out reset facility                        *
*   and differentiation between POR, BOR and MCLR resets                *
*                                                                       *
*   Turns on POR LED only if power-on reset is detected                 *
*   Turns on BOR LED only if brown-out detect reset is detected         *
*   Turns on indicator LED in all cases                                 *
*   (no POR or BOR implies MCLR, as no other reset sources are active)  *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = "on" indicator LED (always turned on)                     *
*       RA1 = POR LED (indicates power-on reset)                        *
*       RA2 = BOR LED (indicates brown-out reset)                       *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, high BOR threshold
#pragma config WDTE = OFF, BOREN = ON, BORV = HI
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define O_LED   LATAbits.LATA0      // "on" indicator LED (always on)
#define P_LED   LATAbits.LATA1      // POR LED to indicate power-on reset
#define B_LED   LATAbits.LATA2      // BOR LED to indicate brown-out reset


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure port
    LATA = 0;                   // start with all output pins low (LEDs off)
    TRISA = 0b111000;           // configure RA0, RA1 and RA2 as outputs
    
    // check for POR or BOR reset
    if (!PCONbits.nPOR)         // if power-on reset (/POR = 0),
    {
        PCONbits.nPOR = 1;      //   set POR and BOR flags for next reset
        PCONbits.nBOR = 1;
        P_LED = 1;              //   light POR LED
    }
    if (!PCONbits.nBOR)         // if brown-out detect (/BOR = 0)
    {
        PCONbits.nBOR = 1;      //   set BOR flag for next reset
        B_LED = 1;              //   light BOR LED  
    }     
    
    
    /*** Main code ***/
    
    // light "on" indicator LED 
    O_LED = 1;                

    // wait "forever" (until the next reset)
    for (;;)                    
        ;
}
