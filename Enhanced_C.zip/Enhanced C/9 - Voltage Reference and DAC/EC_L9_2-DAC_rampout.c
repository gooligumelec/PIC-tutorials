/************************************************************************
*                                                                       *
*   Filename:      EC_L9_2-DAC_rampout.c                                *
*   Date:          28/5/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 2                                 *
*                                                                       *
*   Outputs sawtooth (rising ramp) waveform on DACOUT                   *
*   F = ~650 Hz, V = 0 - 0.97*Vdd                                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       DACOUT (RA0) = sawtooth output                                  *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
                                    //  -> 8 us / instruction cycle
    
    // configure DAC
    DACCON0bits.DACEN = 1;      // DAC enabled
    DACCON0bits.DACOE = 1;      // DACOUT pin enabled
    DACCON0bits.DACPSS = 0b00;  // +ve source is Vdd
    DACCON0bits.DACNSS = 0;     // -ve source is Vss
                                //  -> output DACR/32*Vdd on DACOUT
    DACCON1bits.DACR = 0;       // initial output = 0 V 
        

    /*** Main loop ***/
    for (;;)
    {
        // continually generate sawtooth (rising ramp) waveform
        //  6 inst cycles/increment * 8 us/inst cycle = 48 us/increment
        //  32 increments/period * 48 us/increment = 1536 us/period
        //  -> Fout = 651 Hz
        DACCON1++;              // increment DAC output level (DACR)
    }
}
