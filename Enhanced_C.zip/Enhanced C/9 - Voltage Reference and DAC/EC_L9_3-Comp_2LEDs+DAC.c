/************************************************************************
*                                                                       *
*   Filename:      EC_L9_3-Comp_2LEDs+DAC.c                             *
*   Date:          28/5/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 3                                 *
*                                                                       *
*   Demonstrates basic use of comparator with DAC                       *
*                                                                       *
*   Turns on Low LED  when C12IN0- < 2.0 V (low light level)            *
*         or High LED when C12IN0- > 3.0 V (high light level)           *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       C12IN0- = voltage to be measured (e.g. pot output or LDR)       *
*       RC3   = "Low" LED                                               *
*       RC1   = "High" LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define HI      LATCbits.LATC1      // "High" LED
#define LO      LATCbits.LATC3      // "Low" LED


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure ports
    TRISC = 0b110101;               // configure RC1 and RC3 as outputs
                                    //  (RA1/C12IN0- is an input)
    ANSELAbits.ANSA1 = 1;           // select analog mode for RA1/C12IN0-  

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
    
    // configure DAC
    DACCON0bits.DACEN = 1;          // DAC enabled
    DACCON0bits.DACOE = 0;          // DACOUT pin disabled
    DACCON0bits.DACPSS = 0b00;      // +ve source is Vdd
    DACCON0bits.DACNSS = 0;         // -ve source is Vss
                                    //  -> DAC out = DACR/32*Vdd
                                    //             = DACR*156 mV (if Vdd = 5.0 V)
        
    // configure comparator 1
    CM1CON0bits.C1ON = 1;           // comparator enabled
    CM1CON0bits.C1OE = 0;           // external output disabled
    CM1CON0bits.C1POL = 0;          // output not inverted
    CM1CON0bits.C1SP = 1;           // normal power mode
    CM1CON0bits.C1HYS = 1;          // hysteresis enabled
    CM1CON0bits.C1SYNC = 0;         // asynchronous output    
    CM1CON1bits.C1PCH = 0b01;       // + in = DAC output
    CM1CON1bits.C1NCH = 0b00;       // - in = C12IN0- pin
                                    //  -> C1OUT = 1 if C12IN0- < DAC
                                
    
    /*** Main loop ***/
    for (;;)
    {
        /*** Test for low illumination ***/
        // set low input threshold
        DACCON1bits.DACR = 13;      // DAC out = 13*156 mV = 2.03 V
        __delay_us(10);             // wait 10 us for DAC to settle
        
        // compare with input
        LO = CM1CON0bits.C1OUT;     // turn on Low LED if C12IN0- < DAC


        /*** Test for high illumination ***/
        // set high input threshold
        DACCON1bits.DACR = 19;      // DAC out = 19*156 mV = 2.97 V
        __delay_us(10);             // wait 10 us for DAC to settle
        
        // compare with input
        HI = ~CM1CON0bits.C1OUT;    // turn on High LED if C12IN0- > DAC             
    }
}
