/************************************************************************
*                                                                       *
*   Filename:      EC_L9_4-2xComp_wakeup.c                              *
*   Date:          29/5/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 4                                 *
*                                                                       *
*   Demonstrates wake-up on dual comparator change                      *
*   using fixed voltage reference and DAC as comparator thesholds       *
*                                                                       *
*   Turns on Low LED  when C12IN0- < 2.0 V (low light level)            *
*         or High LED when C12IN0- > 3.0 V (high light level)           *
*   until input returns to middle (2.0 - 3.0 V) range                   *
*   then sleeps until the next change                                   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       C12IN0- = voltage to be measured (e.g. pot output or LDR)       *
*       RC3   = "Low" LED                                               *
*       RC1   = "High" LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define HI      LATCbits.LATC1      // "High" LED
#define LO      LATCbits.LATC3      // "Low" LED


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0b110101;               // configure RC1 and RC3 as outputs
                                    //  (RA1/C12IN0- is an input)
    ANSELAbits.ANSA1 = 1;           // select analog mode for RA1/C12IN0-            

    // configure fixed voltage reference
    FVRCONbits.FVREN = 1;           // FVR enabled
    FVRCONbits.CDAFVR = 0b10;       // Comp+DAC output is 2x (= 2.048 V)
                                    //  -> output 2.048 V to comparators
                                
    // configure DAC
    DACCON0bits.DACEN = 1;          // DAC enabled
    DACCON0bits.DACOE = 0;          // DACOUT pin disabled
    DACCON0bits.DACPSS = 0b00;      // +ve source is Vdd
    DACCON0bits.DACNSS = 0;         // -ve source is Vss
    DACCON1bits.DACR = 19;          // DAC out = 19/32*Vdd
                                    //         = 2.97 V (if Vdd = 5.0 V)

    // configure comparator 1
    CM1CON0bits.C1ON = 1;           // comparator enabled
    CM1CON0bits.C1OE = 0;           // external output disabled
    CM1CON0bits.C1POL = 1;          // output inverted
    CM1CON0bits.C1SP = 0;           // low-power mode
    CM1CON0bits.C1HYS = 1;          // hysteresis enabled
    CM1CON0bits.C1SYNC = 0;         // asynchronous output    
    CM1CON1bits.C1PCH = 0b01;       // + in = DAC output
    CM1CON1bits.C1NCH = 0b00;       // - in = C12IN0- pin
                                    //  -> C1OUT = 1 if C12IN0- > DAC (2.97 V)
                                    
    // configure comparator 2
    CM2CON0bits.C2ON = 1;           // comparator enabled
    CM2CON0bits.C2OE = 0;           // external output disabled
    CM2CON0bits.C2POL = 0;          // output not inverted
    CM2CON0bits.C2SP = 0;           // low-power mode
    CM2CON0bits.C2HYS = 1;          // hysteresis enabled
    CM2CON0bits.C2SYNC = 0;         // asynchronous output    
    CM2CON1bits.C2PCH = 0b10;       // + in = fixed voltage ref
    CM2CON1bits.C2NCH = 0b00;       // - in = C12IN0- pin
                                    //  -> C2OUT = 1 if C12IN0- < FVR (2.05 V) 
    
    // enable comparator interrupts (for wake on change)
    INTCONbits.PEIE = 1;        // enable peripheral interrupts
                                // enable comparator 1 interrupt:
    CM1CON1bits.C1INTP = 1;     //   enable rising edge detection
    CM1CON1bits.C1INTN = 0;     //   disable falling edge detection                            
                                //   (wake only on rising output transitions)
                                //   ( -> input rose above upper threshold)
    PIE2bits.C1IE = 1;          //   set enable bit    
                                // enable comparator 2 interrupt:
    CM2CON1bits.C2INTP = 1;     //   enable rising edge detection
    CM2CON1bits.C2INTN = 0;     //   disable falling edge detection                            
                                //   (wake only on rising output transitions)
                                //   ( -> input fell below lower threshold)
    PIE2bits.C2IE = 1;          //   set enable bit

                                    
    /*** Main loop ***/
    for (;;)
    {
        // test for and wait while input low
        while (CM2CON0bits.C2OUT)   // while input < low threshold (2.05 V)
        {
            LO = 1;                 //   turn on "low" LED
        }

        // test for and wait while input high
        while (CM1CON0bits.C1OUT)   // while input > high threshold (2.97 V)
        {
            HI = 1;                 //   turn on "high" LED
        }
            
        // input within acceptable range at this point, so turn off LEDs
        LATC = 0;
        
        // go into standby (low power) mode
        PIR2bits.C1IF = 0;          // clear comparator interrupt flags
        PIR2bits.C2IF = 0;
        SLEEP();                    // enter sleep mode
    } 
}


