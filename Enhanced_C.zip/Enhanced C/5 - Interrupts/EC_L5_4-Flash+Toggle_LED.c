/************************************************************************
*                                                                       *
*   Filename:      EC_L5_4-Flash+Toggle_LED.c                           *
*   Date:          16/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 5, example 4                                 *
*                                                                       *
*   Demonstrates use of Timer0 interrupt to implement                   *
*   counting debounce algorithm                                         *
*                                                                       *
*   Toggles LED when the pushbutton is pressed (high -> low)            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*       RA1 = "button pressed" indicator LED                            *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA0      // flashing LED
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED

#define BUTTON  PORTAbits.RA3       // pushbutton


/***** CONSTANTS *****/
#define MAX_DB_CNT  20/2    // maximum debounce count = debounce period / sample rate
                            //   (20 ms debounce period / 2 ms per sample)


/***** GLOBAL VARIABLES *****/
volatile bit    PB_dbstate;     // debounced pushbutton state (0 = pressed)
volatile bit    PB_change;      // pushbutton state change flag (1 = changed)


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = 0b111100;           // configure RA0 and RA1 (only) as outputs
                                // (RA3 is an input) 
                                    
    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz
                                //  -> 8 us / instruction cycle
        
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 1;         // no prescaling
                                    //  -> increment TMR0 every 8 us    

    // initialise variables
    PB_dbstate = 1;                 // initial pushbutton state = released
    PB_change = 0;                  // clear pushbutton change flag (no change)
    
    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        // check for and handle debounced button press
        if (PB_change && !PB_dbstate)   // if button state changed and pressed (low)
        {
            B_LED = ~B_LED;             //   toggle indicator LED
            PB_change = 0;              //   clear button change flag
        }
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  cnt_db = 0;     // debounce counter
    static uint8_t  cnt_t0 = 0;     // counts timer0 interrupts    
    
    //*** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2 ms
    //
    //  Debounces pushbutton:
    //    samples every 2 ms (every interrupt)
    //    -> PB_dbstate = debounced state
    //       PB_change  = change flag (1 = new debounced state)  
    //
    //  Flashes LED at 1 Hz by toggling every 500 ms
    //      (every 250th interrupt)    
    //
    //  (only Timer0 interrupts are enabled)
    //    
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    TMR0 += 256-250+3;              // add value to Timer0
                                    //   for overflow after 250 counts    
 
    // Debounce pushbutton 
    //   use counting algorithm: accept change in state
    //   only if new state is seen a number of times in succession
    
    // compare raw pushbutton with current debounced state
    if (BUTTON == PB_dbstate)   // if raw pushbutton matches current debounce state,
        cnt_db = 0;             //   reset debounce count
    else                        // else raw pushbutton has changed state
    {
        ++cnt_db;                   // increment debounce count
        if (cnt_db == MAX_DB_CNT)   // when max count is reached
        {                               // accept new state as changed:
            PB_dbstate = BUTTON;        //   update debounced state
            cnt_db = 0;                 //   reset debounce count
            PB_change = 1;              //   set pushbutton changed flag
                                        //   (polled and cleared in main loop)
        }
    } 
    
    // toggle LED every 500 ms
    ++cnt_t0;                       // increment interrupt count (every 2 ms) 
    if (cnt_t0 == 500/2)            // if count overflow (every 500 ms)
    {
        cnt_t0 = 0;                 //   reset count
        F_LED = ~F_LED;             //   toggle LED      
    }                                                     
}
