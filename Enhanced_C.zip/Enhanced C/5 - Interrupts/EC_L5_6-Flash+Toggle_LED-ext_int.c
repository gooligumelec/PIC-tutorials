/************************************************************************
*                                                                       *
*   Filename:      EC_L5_6-Flash+Toggle_LED-ext_int.c                   *
*   Date:          17/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 5, example 6                                 *
*                                                                       *
*   Demonstrates handling of multiple interrupt sources                 *
*                                                                       *
*   Toggles an LED when pushbutton on INT is pressed                    *
*   (high -> low transition triggering external interrupt)              *
*   while another LED flashes at 1 Hz (driven by Timer0 interrupt)      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*       RA1 = "button pressed" indicator LED                            *
*       INT = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA0      // flashing LED
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                       // start with all output pins low (LED off)
    TRISA = 0b111100;               // configure RA0 and RA1 (only) as outputs
    ANSELA = 0;                     // disable analog input mode for all pins
                                    //  -> INT(RA2) is a digital input
                                                                        
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
                                    //  -> 8 us / instruction cycle
        
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 1;         // no prescaling
                                    //  -> increment TMR0 every 8 us    

    // configure external interrupt
    OPTION_REGbits.INTEDG = 0;      // trigger on falling edge 
    
    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    INTCONbits.INTF = 0;            // clear external interrupt flag
    INTCONbits.INTE = 1;            // enable external interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  cnt_t0 = 0;     // counts timer0 interrupts    

    // Service all triggered interrupt sources
    
    if (INTCONbits.INTF)    
    {
        //*** Service external interrupt
        //
        //  Triggered on high -> low transition on INT pin
        //  caused by externally debounced pushbutton press
        // 
        //  Toggles LED on every high -> low transition
        //   
        INTCONbits.INTF = 0;            // clear interrupt flag
    
        // toggle indicator LED
        B_LED = ~B_LED;  
    }      
    
    if (INTCONbits.TMR0IF)
    {   
        //*** Service Timer0 interrupt
        //
        //  TMR0 overflows every 2 ms
        //
        //  Flashes LED at 1 Hz by toggling on every 250th interrupt
        //      (every 500 ms)
        //    
        INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
        TMR0 += 256-250+3;              // add value to Timer0
                                        //   for overflow after 250 counts    
    
        // toggle LED every 500 ms
        ++cnt_t0;                       // increment interrupt count (every 2 ms) 
        if (cnt_t0 == 500/2)            // if count overflow (every 500 ms)
        {
            cnt_t0 = 0;                 //   reset count
            F_LED = ~F_LED;             //   toggle flashing LED      
        } 
    }         
}
