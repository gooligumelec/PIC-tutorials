/************************************************************************
*                                                                       *
*   Filename:      EC_L5_1a-Flash_LED-50p-int.c                         *
*   Date:          15/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 5, example 1a                                *
*                                                                       *
*   Demonstrates use of Timer0 interrupt to perform a background task   *
*                                                                       *
*   Flash an LED approximately once per second (50% duty cycle)         *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA0      // flashing LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = 0b111110;           // configure RA0 (only) as an output
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz
                                //  -> 8 us / instruction cycle
        
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b111;      // prescale = 256
                                    //  -> increment TMR0 every 2048 us   

    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service Timer0 interrupt
    //
    //  TMR0 overflows every 524 ms
    //
    //  Flashes LED at ~0.95 Hz by toggling on each interrupt
    //      (every ~524 ms)
    //
    //  (only Timer0 interrupts are enabled)
    //    
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    // toggle LED
    F_LED = ~F_LED;              
}
