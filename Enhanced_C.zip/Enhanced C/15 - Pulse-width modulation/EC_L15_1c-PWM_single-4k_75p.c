/************************************************************************
*                                                                       *
*   Filename:      EC_L15_1c-PWM_single-4k_75p.c                        *
*   Date:          4/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 15, example 1c                               *
*                                                                       *
*   Demonstrates basic single-output PWM (fixed freq and duty cycle)    *
*                                                                       *
*   PWM output is 4 kHz, active-high, 75% duty cycle                    * 
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP4 = PWM output                                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<1);                // configure PORTC as all inputs
                                    //   except RC1 (CCP4 output)

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C4TSEL = 0b00;      // use Timer2 with CCP4
    // configure Timer2
    T2CONbits.T2CKPS = 0b00;        // prescale = 1 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 1 us
    PR2 = 249;                      // period = 250 x 1 us = 250 us
                                    //  -> PWM frequency = 4 kHz
    // configure CCP4
    CCP4CONbits.DC4B = 0b10;        // LSBs of PWM duty cycle = 10
    CCP4CONbits.CCP4M = 0b1100;     // select PWM mode               
                                    //  -> single PWM output on CCP4
    CCPR4L = 187;                   // CCPR4L:DC4B<1:0> = 750 -> pulse width = 187.5 us                                
                                    //  -> PWM duty cycle = 75%                                    

                 
    /*** Main loop ***/  
    for (;;)
    {
        // do nothing
        ;
    } 
}
