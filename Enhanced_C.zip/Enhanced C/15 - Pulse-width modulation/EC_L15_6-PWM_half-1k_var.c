/************************************************************************
*                                                                       *
*   Filename:      EC_L15_6-PWM_half-4k_var.c                           *
*   Date:          1/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 15, example 6                                *
*                                                                       *
*   Demonstrates varying half-bridge output PWM duty cycle              *
*                                                                       *
*   Outputs complementary PWM signals (~977 Hz) on P2A and P2B          *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       P2A, P2B = complementary PWM outputs (active high)              *
*       AN0      = analog input (e.g. pot or LDR)                       *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<3|1<<2);           // configure PORTC as all inputs
                                    //   except RC3 and RC3 (P2A, P2B outputs)
    ANSELA = 1<<0;                  // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2 us (with Fosc = 4 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C2TSEL = 0b00;      // use Timer2 with ECCP2
    // configure Timer2
    T2CONbits.T2CKPS = 0b01;        // prescale = 4 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 4 us
    PR2 = 255;                      // period = 256 x 4 us = 1024 us
                                    //  -> PWM frequency = 977 Hz
    // configure ECCP2
    CCP2CONbits.P2M = 0b10;         // half-bridge output, P2A, P2B active
    CCP2CONbits.DC2B = 0b00;        // LSBs of PWM duty cycle = 00
    CCP2CONbits.CCP2M = 0b1100;     // PWM mode: all active-high               
                                    //  -> half-bridge output mode,
                                    //      P2A, P2B active-high

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;

        // set new PWM duty cycle
        CCPR2L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
