/************************************************************************
*                                                                       *
*   Filename:      EC_L15_3-PWM_single-244_var.c                        *
*   Date:          29/10/15                                             *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 15, example 3                                *
*                                                                       *
*   Demonstrates varying single-output PWM duty cycle                   *
*                                                                       *
*   Outputs PWM signal (~244 Hz) on CCP3                                *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP3 = PWM output (e.g. LED or motor)                           *
*       AN0  = analog input (e.g. pot or LDR)                           *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISA = ~(1<<2);                // configure PORTC as all inputs
                                    //   except RA2 (CCP3 output)
    ANSELA = 1<<0;                  // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2 us (with Fosc = 4 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C3TSEL = 0b01;      // use Timer4 with CCP4
    // configure Timer4
    T4CONbits.T4CKPS = 0b10;        // prescale = 16 
    T4CONbits.TMR4ON = 1;           // enable timer
                                    //  -> TMR4 increments every 16 us
    PR4 = 255;                      // period = 256 x 16 us = 4096 us
                                    //  -> PWM frequency = 244 Hz
    // configure CCP3
    CCP3CONbits.DC3B = 0b00;        // LSBs of PWM duty cycle = 00
    CCP3CONbits.CCP3M = 0b1100;     // select PWM mode               
                                    //  -> single PWM output on CCP3

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;

        // set new PWM duty cycle
        CCPR3L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
