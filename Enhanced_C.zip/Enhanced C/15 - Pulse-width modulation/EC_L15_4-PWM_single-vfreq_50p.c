/************************************************************************
*                                                                       *
*   Filename:      EC_L15_4-PWM_single-vfreq_50p.c                      *
*   Date:          4/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 15, example 4                                *
*                                                                       *
*   Demonstrates varying single-output PWM frequency (fixed duty cycle) *
*                                                                       *
*   Sounds piezo on P1A at 244 - 62500 Hz,                              * 
*   with frequency derived from an analog input                         *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       P1A = PWM output (e.g. piezo speaker)                           *
*       AN0 = analog input (e.g. pot or LDR)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    uint16_t     period;            // PWM period (= PR2+1)
    
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<5);                // configure PORTC as all inputs
                                    //   except RC5 (P1A output)
    ANSELA = 1<<0;                  // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2 us (with Fosc = 4 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C1TSEL = 0b00;      // use Timer2 with ECCP1
    // configure Timer2
    T2CONbits.T2OUTPS = 0;          // postscale = 1:1
    T2CONbits.T2CKPS1 = 1;          // prescale = 16 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 16 us
    // configure ECCP1 
    CCP1CONbits.P1M = 0b00;         // select single output mode
                                    //  -> P1A active
    CCP1CONbits.DC1B = 0b00;        // LSBs of PWM duty cycle = 00
    CCP1CONbits.CCP1M = 0b1100;     // select PWM mode: all active-high                
                                    //  -> single active-high PWM output on P1A

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;

        // wait for end of PWM period
        PIR1bits.TMR2IF = 0;        // clear Timer2 interrupt flag
        while (!PIR1bits.TMR2IF)    // then wait for it to go high
            ;

        // set new PWM period
        PR2 = ADRESH;               // PWM period = high byte of ADC result + 1
        
        // set duty cycle to 50%
        period = PR2+1;
        CCPR1L = period/2;              // CCPR1L:DCB<1:0> = (period x 4) / 2
        CCP1CONbits.DC1B1 = period%2;   //  -> PWM duty cycle = 50%
    } 
}
