/************************************************************************
*                                                                       *
*   Filename:      EC_L15_7b-PWM_full_r-244_var.c                       *
*   Date:          4/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 15, example 7b                               *
*                                                                       *
*   Demonstrates full-bridge reverse PWM mode,                          *
*   with variable duty cycle                                            *
*                                                                       *
*   Outputs PWM signals (~244 Hz) on P1A-D in full-bridge reverse mode  *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       P1A  = inactive (high) output                                   *
*       P1B  = modulated PWM output (active high)                       *
*       P1C  = active (low) output                                      *
*       P1D  = inactive output (low)                                    *
*       AN0  = analog input (e.g. pot)                                  *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0b000011;               // configure PORTC as all inputs
                                    //   except RC2-5 (P1A-D outputs)
    ANSELA = 1<<0;                  // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2 us (with Fosc = 4 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C1TSEL = 0b01;      // use Timer4 with ECCP1
    // configure Timer4
    T4CONbits.T4CKPS = 0b10;        // prescale = 16 
    T4CONbits.TMR4ON = 1;           // enable timer
                                    //  -> TMR4 increments every 16 us
    PR4 = 255;                      // period = 256 x 16 us = 4096 us
                                    //  -> PWM frequency = 244 Hz
    // configure ECCP1
    CCP1CONbits.P1M = 0b11;         // select full-bridge output reverse mode
                                    //  -> PIB modulated, P1C active, P1A, PID inactive
    CCP1CONbits.DC1B = 0b00;        // LSBs of PWM duty cycle = 00
    CCP1CONbits.CCP1M = 0b1110;     // select PWM mode: P1A, P1C active-low
                                    //                  P1B, P1D active-high                
                                    //  -> full-bridge output reverse mode,
                                    //      P1B modulated (active-high)
                                    //      P1C active (low)
                                    //      P1A inactive (high)
                                    //      P1D inactive (low)

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;

        // set new PWM duty cycle
        CCPR1L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
