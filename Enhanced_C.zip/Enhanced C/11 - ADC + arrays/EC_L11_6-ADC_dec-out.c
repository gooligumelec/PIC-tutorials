/************************************************************************
*                                                                       *
*   Filename:      EC_L11_6-ADC_dec-out.c                               *
*   Date:          19/8/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 6                                *
*                                                                       *
*   Displays ADC output in decimal on 2x7-segment LED displays          *
*                                                                       *
*   Continuously samples analog input, scales result to 0 - 99          *
*   and displays as 2 x dec digits on multiplexed 7-seg displays        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = tens digit enable (active high)               *
*       RA5             = ones digit enable                             *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   8000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define TENS_EN         LATCbits.LATC5      // "tens" digit enable (RC5)
#define ONES_EN         LATAbits.LATA5      // ones digit enable (RA5)
    

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** GLOBAL VARIABLES *****/
uint8_t     dsp_tens = 0;           // digits to be displayed by ISR: tens
uint8_t     dsp_ones = 0;           // ones


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     adc_dec;            // scaled ADC output (0-99)
    uint8_t     adc_tens;           //   as extracted digits: tens
    uint8_t     adc_ones;           //                        ones 

       
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSELAbits.ANSA2 = 1;           // select analog mode for RA2
                                    //  -> RA2/AN2 is an analog input
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1110;       // internal oscillator = 8 MHz

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b011;      // prescale = 16
                                    //  -> increment TMR0 every 8 us
                                    //  -> TMR0 overflows every 2.048 ms    
                                    
    // configure ADC     
    ADCON1bits.ADCS = 0b101;        // Tad = 16*Tosc = 2 us (with Fosc = 8 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00010;       // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on

    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts
    
            
    /*** Main loop ***/
    for (;;)
    {
        // sample analog input
        __delay_us(10);                 // wait 10 us (acquisition time)
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;
        
        // scale 8-bit ADC result to 0-99
        adc_dec = (unsigned)ADRESH * 100/256;
        
        // extract digits of scaled result
        adc_ones = (unsigned)adc_dec%10;   
        adc_tens = (unsigned)adc_dec/10;
                    
        // disable interrupts during display variable and port update
        // (ensures consistent display)
        di();
                        
            // copy digits to ISR display variables
            dsp_ones = adc_ones;   
            dsp_tens = adc_tens; 
        
        // re-enable interrupts
        ei(); 
    }      
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
    
    // *** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2.048 ms
    //
    //  Displays current scaled ADC result (in dec)
    //    on 7-segment displays
    //
    //  (only Timer0 interrupts are enabled)
    //
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    // Display current scaled ADC result on 2 x 7-segment displays
    //   mpx_cnt determines current digit to display
    //
    switch (mpx_cnt)
    {
        case 0: 
            // display ones digit       
            set7seg(dsp_ones);              // output ones digit  
            ONES_EN = 1;                    // enable ones display
            break;
        case 1:
            // display tens digit        
            set7seg(dsp_tens);              // output tens digit  
            TENS_EN = 1;                    // enable tens display
            break;
    }
    // Increment mpx_cnt, to select next digit for next time
    mpx_cnt++;
    if (mpx_cnt == 2)       // reset count if at end of digit sequence
        mpx_cnt = 0;
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011    // 9 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    }; 
    
    // disable displays
    LATA = 0;               // clear all digit enable lines on PORTA
    LATC = 0;               //  and PORTC
    
    // lookup and output digit pattern
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}