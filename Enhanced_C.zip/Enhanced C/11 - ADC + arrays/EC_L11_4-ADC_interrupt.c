/************************************************************************
*                                                                       *
*   Filename:      EC_L11_4-ADC_interrupt.c                             *
*   Date:          1/8/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 4                                *
*                                                                       *
*   Displays ADC output in hexadecimal on 7-segment LED displays        *
*                                                                       *
*   Regularly samples analog input, using timer and ADC interrupts,     *
*   displaying result as 3 x hex digits on multiplexed 7-seg displays   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = "hundreds" digit enable (active high)         *
*       RA5             = "tens" digit enable                           *
*       RC0             = ones digit enable                             *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define HUNDREDS_EN     LATCbits.LATC5      // "hundreds" digit enable (RC5)
#define TENS_EN         LATAbits.LATA5      // "tens" digit enable (RA5)
#define ONES_EN         LATCbits.LATC0      // ones digit enable (RC0)
    

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** GLOBAL VARIABLES *****/
uint8_t     hundreds = 0;       // current ADC result (in hex): "hundreds"
uint8_t     tens = 0;           //  "tens"
uint8_t     ones = 0;           //  ones


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSELAbits.ANSA2 = 1;           // select analog mode for RA2
                                    //  -> RA2/AN2 is an analog input
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1110;       // internal oscillator = 8 MHz

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b011;      // prescale = 16
                                    //  -> increment TMR0 every 8 us
                                    //  -> TMR0 overflows every 2.048 ms    
                                    
    // configure ADC     
    ADCON1bits.ADCS = 0b101;        // Tad = 16*Tosc = 2 us (with Fosc = 8 MHz) 
    ADCON1bits.ADFM = 1;            // LSB of result in ADRESL<0>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00010;       // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on

    // enable interrupts
    PIR1bits.ADIF = 0;              // clear ADC interrupt flag
    PIE1bits.ADIE = 1;              // enable ADC
    INTCONbits.TMR0IE = 1;          //        Timer0
    INTCONbits.PEIE = 1;            //        peripheral 
    ei();                           // and    global interrupts
    
            
    /*** Main loop ***/
    for (;;)
        ;                           // do nothing      
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
 
    // Service all triggered interrupt sources
    
    if (INTCONbits.TMR0IF)
    {   
        // *** Service Timer0 interrupt
        //
        //  TMR0 overflows every 2.048 ms
        //
        //  Displays current ADC result (in hex) on 7-segment displays
        //
        //  Initiates next analog conversion when display refresh is complete
        //  (every 6 ms)
        //
        INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
        // Display current ADC result (in hex) on 3 x 7-segment displays
        //   mpx_cnt determines current digit to diplay
        //
        switch (mpx_cnt)
        {
            case 0:
                // display ones digit
                set7seg(ones);                  // output ones digit  
                ONES_EN = 1;                    // enable ones display
                break;
                
            case 1:
                // display "tens" digit
                set7seg(tens);                  // output "tens" digit  
                TENS_EN = 1;                    // enable "tens" display
                break;
                
            case 2:
                // display "hundreds" digit
                set7seg(hundreds);              // output "hundreds" digit
                HUNDREDS_EN = 1;                // enable "hundreds" display
                
                // initiate next analog-to-digital conversion
                ADCON0bits.GO = 1;         
                break;
        }
        // Increment mpx_cnt, to select next digit for next time
        mpx_cnt++;
        if (mpx_cnt == 3)       // reset count if at end of digit sequence
            mpx_cnt = 0;
    }  
    
    if (PIR1bits.ADIF)
    {
        // *** Service ADC interrupt
        //
        //  Conversion is initiated by Timer0 interrupt, every 6 ms
        //
        PIR1bits.ADIF = 0;                      // clear interrupt flag
        
        // copy ADC result to display variables
        //  (to be displayed by Timer0 handler)
        ones = ADRESL & 0x0F;   // get ones digit from low nybble of ADRESL
        tens = ADRESL >> 4;     // get "tens" digit from high nybble of ADRESL
        hundreds = ADRESH;      // get "hundreds" digit from ADRESH        
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011,   // 9 
        0b010011,   // A
        0b010011,   // b
        0b010010,   // C
        0b010001,   // d
        0b010011,   // E
        0b010011    // F           
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // disable displays
    LATA = 0;               // clear all digit enable lines on PORTA
    LATC = 0;               //  and PORTC
    
    // lookup and output digit pattern
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}
