/************************************************************************
*                                                                       *
*   Filename:      EC_L6_2-2xToggle_LED-IOC.c                           *
*   Date:          16/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 6, example 2                                 *
*                                                                       *
*   Demonstrates handling of multiple interrupt-on-change interrupts    *
*   (without software debouncing)                                       *
*                                                                       *
*   Toggles LED on RA0 when pushbutton on RA2 is pressed                *
*   (high -> low transition)                                            *
*   and LED on RA1 when pushbutton on RA4 is pressed                    *
*   (low -> high transition)                                            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = indicator LED 1                                           *
*       RA1 = indicator LED 2                                           *
*       RA2 = pushbutton 1 (externally debounced, active low)           *
*       RA4 = pushbutton 2 (externally debounced, active high)          *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define B1_LED  LATAbits.LATA0   // "button 1 pressed" indicator LED 
#define B2_LED  LATAbits.LATA1   // "button 2 pressed" indicator LED 
#define nPB1    2           // pushbutton 1 (ext debounce, active low) on RA2
#define nPB2    4           // pushbutton 2 (ext debounce, active high) on RA4


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                       // start with all output pins low
    TRISA = 0b111100;               // configure RA0 and RA1 as outputs
    ANSELA = 0;                     // disable analog input mode for all pins
                                    //  -> RA2 and RA4 are digital inputs
                                    
    // configure interrupt-on-change                                    
    IOCAN = 1<<nPB1;            // enable detection of falling edges on PB1 input
    IOCAP = 1<<nPB2;            // and rising edges on PB2 input    
    
    // enable interrupts
    INTCONbits.IOCIE = 1;           // enable IOC interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service port change interrupt
    //
    //  Triggered on any valid transition on IOC-enabled input pins
    //  caused by externally debounced pushbutton press
    //
    //  Toggles LED1 on every valid transition of PB1 (high -> low)
    //      and LED2 on every valid transition of PB2 (low -> high)
    //
    //  (only port change interrupts are enabled)       
    //    
      
    // toggle LED 1 only on button 1 press
    if (IOCAF & 1<<nPB1)            // if button 1 changed
    {       
        IOCAF &= ~(1<<nPB1);        //  clear pin change flag
        B1_LED = ~B1_LED;           //  toggle LED 1
    }
    
    // toggle LED 2 only on button 2 press
    if (IOCAF & 1<<nPB2)            // if button 2 changed
    {       
        IOCAF &= ~(1<<nPB2);        //  clear pin change flag
        B2_LED = ~B2_LED;           //  toggle LED 2
    }
}
