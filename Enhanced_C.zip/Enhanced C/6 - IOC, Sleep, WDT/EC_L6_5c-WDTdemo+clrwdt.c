/************************************************************************
*                                                                       *
*   Filename:      EC_L6_5c-WDTdemo+clrwdt.c                            *
*   Date:          18/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 6, example 5c                                *
*                                                                       *
*   Demonstrates clearing the watchdog timer                            *
*                                                                       *
*   Turn on LED for 1 s, turn off, then enter endless loop              *
*       WDT is cleared in the endless loop, so                          *
*       LED stays off, even when the watchdog is enabled                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
#define     WATCHDOG            // define to enable watchdog timer

#ifdef WATCHDOG
    //  no watchdog timer
    #pragma config WDTE = ON
#else
    //  no watchdog timer
    #pragma config WDTE = OFF
#endif   

//  ext reset, internal oscillator (no clock out)
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATAbits.LATA1      // indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    TRISA = 0b111101;               // configure RA1 (only) as an output
 
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
   
    // configure watchdog timer
    WDTCONbits.WDTPS = 0b01011;     // prescale = 65536 (-> WDT timeout = 2 sec)

    
    //*** Main code
    LED = 1;                    // turn on LED
    
    __delay_ms(1000);           // delay 1 sec
   
    LED = 0;                    // turn off LED 
    
    for (;;)                    // repeatedly clear watchdog timer forever
        CLRWDT(); 
}
