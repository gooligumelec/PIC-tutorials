/************************************************************************
*                                                                       *
*   Filename:      EC_L6_3c-Sleep_LED_off-LP.c                          *
*   Date:          17/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 6, example 3c                                *
*                                                                       *
*   Demonstrates use of low-power sleep mode                            *
*   (voltage regulator in low-power mode and BOR off in sleep)          *
*                                                                       *
*   Turn on LED, wait for button press, turn off LED, then sleep        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*       RA3 = pushbutton (active low)                                   *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout reset on (off in sleep), low brownout voltage, no low-power brownout reset
#pragma config BOREN = NSLEEP, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATAbits.LATA1      // indicator LED
#define BUTTON  PORTAbits.RA3       // pushbutton (active low)


/***** MAIN PROGRAM *****/
void main()
{
    //***** Initialisation
    
    // configure port    
    TRISA = 0b111101;               // configure RA1 (only) as an output
    
    // configure sleep mode
    VREGCONbits.VREGPM = 1;         // enable low-power sleep mode


    //***** Main code 
     
    // turn on LED    
    LED = 1;                  
    
    // wait for button press
    while (BUTTON == 1)         // wait until button low
        ;

    // go into standby (low power) mode
    LED = 0;                    // turn off LED
    SLEEP();                    // enter sleep mode

    for (;;)                    // (this loop should never execute)
        ;
}
