/************************************************************************
*                                                                       *
*   Filename:      EC_L3_1-PB_LED.c                                     *
*   Date:          19/1/14                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 3, example 1                                 *
*                                                                       *
*   Demonstrates reading a switch                                       *
*                                                                       *
*   Turns on LED when pushbutton is pressed                             *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = LED                                                       *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation

    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = ~(1<<1);            // configure RA1 (only) as an output
                                // (RA3 is an input)

    //*** Main loop
    for (;;)
    {
        // turn on LED only if button pressed
        LATAbits.LATA1 = ~PORTAbits.RA3;            // copy !RA3 to RA1
    }  
}
