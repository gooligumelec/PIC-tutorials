/************************************************************************
*                                                                       *
*   Filename:      EC_L3_2b-Toggle_LED-delay.c                          *
*   Date:          25/12/13                                             *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.21 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 3, example 2b                                *
*                                                                       *
*   Demonstrates use of a simple delay for debouncing                   *
*                                                                       *
*   Toggles LED when pushbutton is pressed then released                *
*   (using a 20 ms debounce delay)                                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = LED                                                       *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation

    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = ~(1<<1);            // configure RA1 (only) as an output
                                // (RA3 is an input)

    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz
    
    
    //*** Main loop
    for (;;)
    {
        // wait for button press
        while (PORTAbits.RA3 == 1)          // wait until RA3 low
            ;
            
        // toggle LED
        LATAbits.LATA1 = ~LATAbits.LATA1;   // toggle RA1 output
        
        // delay to debounce button press
        __delay_ms(20);                     // delay 20 ms
                  
        // wait for button release
        while (PORTAbits.RA3 == 0)          // wait until RA3 high
            ;

        // delay to debounce button release
        __delay_ms(20);                     // delay 20 ms            
    }  
}
