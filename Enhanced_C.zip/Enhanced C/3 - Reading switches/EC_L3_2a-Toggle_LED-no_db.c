/************************************************************************
*                                                                       *
*   Filename:      EC_L3_2a-Toggle_LED-no_db.c                          *
*   Date:          24/12/13                                             *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.21 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 3, example 2a                                *
*                                                                       *
*   Demonstrates the need for debouncing                                *
*                                                                       *
*   Toggles LED when pushbutton is pressed then released                *
*   (no debounce)                                                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = LED                                                       *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation

    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = ~(1<<1);            // configure RA1 (only) as an output
                                // (RA3 is an input)

    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b1111;   // internal oscillator = 16 MHz
    
    
    //*** Main loop
    for (;;)
    {
        // wait for button press
        while (PORTAbits.RA3 == 1)          // wait until RA3 low
            ;
            
        // toggle LED
        LATAbits.LATA1 = ~LATAbits.LATA1;   // toggle RA1 output
                  
        // wait for button release
        while (PORTAbits.RA3 == 0)          // wait until RA3 high
            ;
    }  
}
