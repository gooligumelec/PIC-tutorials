/************************************************************************
*                                                                       *
*   Filename:      EC_L8_3-Comp2_Interrupt.c                            *
*   Date:          16/5/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 8, example 3                                 *
*                                                                       *
*   Demonstrates use of comparator interrupt                            *
*   (assumes hysteresis is used to reduce triggering)                   *
*                                                                       *
*   Turns on LED when input on C12IN0- < threshold on C2IN+             *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       C12IN0- = voltage to be measured (e.g. pot output or LDR)       *
*       C2IN+   = threshold voltage (set by voltage divider resistors)  *
*       C2OUT   = comparator output (fed back to threshold via resistor)*
*       RC1     = indicator LED                                         *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATCbits.LATC1      // indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0b101101;           // configure RC1 and RC4/C2OUT as outputs
                                // (RA1/C12IN0- and RC0/C2IN+ are inputs)
    ANSELAbits.ANSA1 = 1;       // select analog mode for RA1/C12IN0-  
    ANSELCbits.ANSC0 = 1;       //                    and RC0/C2IN+            
    
    // configure comparator 2
    CM2CON0bits.C2ON = 1;       // comparator enabled
    CM2CON0bits.C2OE = 1;       // external output enabled
    CM2CON0bits.C2POL = 0;      // output not inverted
    CM2CON0bits.C2SP = 1;       // normal power mode
    CM2CON0bits.C2HYS = 0;      // hysteresis disabled
    CM2CON0bits.C2SYNC = 0;     // asynchronous output    
    CM2CON1bits.C2PCH = 0b00;   // + in = C2IN+ pin
    CM2CON1bits.C2NCH = 0b00;   // - in = C12IN0- pin
                                //  -> C2OUT = 1 if C12IN0- < C2IN+ 
                                
    // enable interrupts
    INTCONbits.PEIE = 1;        // enable peripheral interrupts
    ei();                       // enable global interrupts
                                // enable comparator 2 interrupt:
    CM2CON1bits.C2INTP = 1;     //   enable rising edge detection
    CM2CON1bits.C2INTN = 1;     //   enable falling edge detection                            
                                //     -> interrupt on all transitions
    PIR2bits.C2IF = 1;          //   set interrupt flag (forces immediate interrupt)
                                //     -> will set initial LED state
    PIE2bits.C2IE = 1;          //   set enable bit

                                    
    /*** Main loop ***/
    for (;;)
    {
        ;   // (do nothing)             
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service comparator 2 interrupt
    //
    //  Triggered on any comparator 2 output change,
    //
    //  Turns on indicator LED if C2OUT is high
    //
    //  (only comparator 2 interrupts are enabled)       
    //   
    PIR2bits.C2IF = 0;          // clear interrupt flag
    
    // display current comparator 2 output
    LED = CM2CON0bits.C2OUT;
}
