/************************************************************************
*                                                                       *
*   Filename:      EC_L10_1b-Count_7seg_x1-single.c                     *
*   Date:          19/6/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 10, example 1b                               *
*                                                                       *
*   Demonstrates use of lookup tables to drive a 7-segment display      *
*                                                                       *
*   Single digit 7-segment display counts repeating 0 -> 9              *
*   1 second per count, with timing derived from int RC oscillator      *
*   (single pattern lookup array)                                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** LOOKUP TABLES *****/

// pattern table for 7 segment display on ports A and C
const uint8_t pat7seg[10] = {
    // RC4:1,RA4,RA1:0 = CDBAEFG
    0b1111110,  // 0
    0b1010000,  // 1
    0b0111101,  // 2
    0b1111001,  // 3
    0b1010011,  // 4
    0b1101011,  // 5
    0b1101111,  // 6
    0b1011000,  // 7
    0b1111111,  // 8
    0b1111011   // 9
}; 


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     digit;              // digit to be displayed

    
    /*** Initialisation ***/ 
    
    // configure ports    
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
    

    /*** Main loop ***/        
    for (;;)
    {
        // display each digit from 0 to 9 for 1 sec
        for (digit = 0; digit < 10; digit++)
        {
            // display digit by extracting pattern bits for all pins
            LATA = (pat7seg[digit] & 1<<2) << 2 |       // RA4 
                   (pat7seg[digit] & 0b00000011);       // RA0-1  
            LATC = (pat7seg[digit] >> 2) & 0b011110;    // RC1-4  
        
            // delay 1 sec
            __delay_ms(1000);
        }  
    }      
}
