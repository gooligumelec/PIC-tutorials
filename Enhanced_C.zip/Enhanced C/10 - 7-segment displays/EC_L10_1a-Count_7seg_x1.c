/************************************************************************
*                                                                       *
*   Filename:      EC_L10_1a-Count_7seg_x1.c                            *
*   Date:          19/6/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 10, example 1a                               *
*                                                                       *
*   Demonstrates use of lookup tables to drive a 7-segment display      *
*                                                                       *
*   Single digit 7-segment display counts repeating 0 -> 9              *
*   1 second per count, with timing derived from int RC oscillator      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** LOOKUP TABLES *****/

// pattern table for 7 segment display on port A
const uint8_t pat7segA[10] = {
    // RA4 = E, RA1:0 = FG
    0b010010,   // 0
    0b000000,   // 1
    0b010001,   // 2
    0b000001,   // 3
    0b000011,   // 4
    0b000011,   // 5
    0b010011,   // 6
    0b000000,   // 7
    0b010011,   // 8
    0b000011    // 9    
}; 

// pattern table for 7 segment display on port C
const uint8_t pat7segC[10] = {
    // RC4:1 = CDBA
    0b011110,   // 0
    0b010100,   // 1
    0b001110,   // 2
    0b011110,   // 3
    0b010100,   // 4
    0b011010,   // 5
    0b011010,   // 6
    0b010110,   // 7
    0b011110,   // 8
    0b011110    // 9
};  


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     digit;              // digit to be displayed

    
    /*** Initialisation ***/ 
    
    // configure ports    
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
    

    /*** Main loop ***/        
    for (;;)
    {
        // display each digit from 0 to 9 for 1 sec
        for (digit = 0; digit < 10; digit++)
        {
            // display digit
            LATA = pat7segA[digit];     // lookup port A and C patterns
            LATC = pat7segC[digit];
        
            // delay 1 sec
            __delay_ms(1000);
        }  
    }      
}
