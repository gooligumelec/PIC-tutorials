/************************************************************************
*                                                                       *
*   Filename:      EC_L10_2b-Count_7seg_x3.c                            *
*   Date:          20/6/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 10, example 2b                               *
*                                                                       *
*   Demonstrates use of timer-based interrupt-driven multiplexing       *
*   to drive multiple 7-seg displays                                    *
*                                                                       *
*   3 digit 7-segment LED display: 1 digit minutes, 2 digit seconds     *
*   counts in seconds 0:00 to 9:59 then repeats,                        *
*   with timing derived from int RC oscillator                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*       RC5              = minutes digit enable (active high)           *
*       RA5              = tens digit enable                            *
*       RC0              = ones digit enable                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   8000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define MINS_EN     LATCbits.LATC5  // minutes digit enable (RC5)
#define TENS_EN     LATAbits.LATA5  // tens digit enable (RA5)
#define ONES_EN     LATCbits.LATC0  // ones digit enable (RC0)


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** GLOBAL VARIABLES *****/
uint8_t     mins = 0;     	        // time counters (displayed by ISR)
uint8_t     secs = 0;
    

/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure ports    
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1110;       // internal oscillator = 8 MHz

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b011;      // prescale = 16
                                    //  -> increment TMR0 every 8 us
                                    //  -> TMR0 overflows every 2.048 ms
                                    
    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts
        

    /*** Main loop ***/        
    for (;;)
    {
        // count minutes:seconds from 0:00 to 9:59
        // (displayed by ISR)
        for (mins = 0; mins < 10; mins++)
        {
            for (secs = 0; secs < 60; secs++)
            {
                __delay_ms(1000);           // delay 1 sec
            }
        }  
    }          
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
        
    // *** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2.048 ms
    //
    //  Displays current count on 7-segment displays
    //
    //  (only Timer0 interrupts are enabled)
    //
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    // Display current count on 3 x 7-segment displays
    //   mpx_cnt determines current digit to diplay
    //
    switch (mpx_cnt)
    {
        case 0: 
            set7seg(secs%10);           // output ones digit  
            ONES_EN = 1;                // enable ones display
            break;
        case 1:
            set7seg(secs/10);           // output tens digit  
            TENS_EN = 1;                // enable tens display
            break;
        case 2:
            set7seg(mins);              // output minutes digit
            MINS_EN = 1;                // enable minutes display
            break;
    }
    // Increment mpx_cnt, to select next digit for next time
    mpx_cnt++;
    if (mpx_cnt == 3)       // reset count if at end of digit sequence
        mpx_cnt = 0;
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011    // 9    
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    };  
    
    // disable displays
    LATA = 0;               // clear all digit enable lines on PORTA
    LATC = 0;               //  and PORTC
    
    // lookup and output digit pattern
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}