/************************************************************************
*                                                                       *
*   Filename:      EC_L12_4-Flash_LED-32k_clock.c                       *
*   Date:          2/12/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 4                                *
*                                                                       *
*   Demonstrates basic use of Timer1 LP oscillator                      *
*                                                                       *
*   LED flashes at 1 Hz (50% duty cycle), with timing derived           *
*   from 32.768 kHz crystal driven by Timer1 oscillator                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1   = flashing LED                                            *
*       T1OSI, T1OSO = 32.768 kHz crystal                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA1      // flashing LED on RA1


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATA = 0;                       // start with all output pins low (all LEDs off)
    TRISA = 0b111101;               // configure led pin (RA1) as an output
                                    
    // configure Timer1
    T1CONbits.TMR1CS = 0b10;        // external clock  
    T1CONbits.T1OSCEN = 1;          // oscillator enabled   
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable Timer1
                                    //  -> increment TMR1 at 32.768 kHz
    
                 
    /*** Main loop ***/
    for (;;)
    {
        // TMR1<14> cycles at 1 Hz, so continually copy to LED
        F_LED = (TMR1 & 1<<14) != 0;    // F_LED = TMR1<14>                              
    } 
}
