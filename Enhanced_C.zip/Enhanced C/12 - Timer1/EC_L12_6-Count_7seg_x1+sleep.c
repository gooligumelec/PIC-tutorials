/************************************************************************
*                                                                       *
*   Filename:      EC_L12_6-Count_7seg_x1+sleep.c                       *
*   Date:          3/12/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-enh.h     (provides debounce macros)      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 6                                *
*                                                                       *
*   Demonstrates use of Timer1 LP oscillator during sleep mode          *
*                                                                       *
*   Single digit 7-segment LED display counts repeating 0 -> 9          *
*   1 count per second, with timing derived from 32.768 kHz crystal     *
*   driven by Timer1 oscillator                                         *
*                                                                       *
*   Device enters sleep mode (and display is blanked) when pushbutton   *
*   is pressed.                                                         *
*   Timer continues to count in sleep mode, maintaining seconds count.  *
*   Device wakes from sleep mode when button is pressed again,          *
*   resuming display and seconds count from the current value.          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       RA3          = sleep/wake pushbutton (active low)               *
*       T1OSI, T1OSO = 32.768 kHz crystal                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#include "stdmacros-enh.h"  // DbnceHi() - debounce switch, wait for high
                            //  (requires TMR0 running at 64 us/tick)
                            

/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define BUTTON  PORTAbits.RA3       // sleep/wake pushbutton (active low)


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** GLOBAL VARIABLES *****/
volatile uint8_t    t1_secs = 0;    // seconds count, updated by Timer1 interrupt


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATA = 0;                       // start with all output pins low 
    LATC = 0;                       //  (all LED segments off)
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;                      //  (RA3 is an input)
    
    // configure interrupt-on-change
    IOCANbits.IOCAN3 = 1;           // enable detection of falling edges on RA3 
    INTCONbits.IOCIE = 1;           // enable wake-up (interrupt) on port change           

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
                                    // -> 8 us / instruction cycle

    // configure Timer0 (for DbnceHi() macro)
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    // -> increment TMR0 every 64 us    
    
    // configure Timer1
    T1CONbits.TMR1CS = 0b10;        // external clock  
    T1CONbits.T1OSCEN = 1;          // oscillator enabled  
    T1CONbits.nT1SYNC = 1;          // asynchronous mode
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
                                    //  -> increment TMR1 at 32.768 kHz
                                    
    T1CONbits.TMR1ON = 0;           // stop Timer1                                    
    TMR1 = 0x8000;                  // start counting from 0x8000
                                    //  -> overflow after 1 sec
    T1CONbits.TMR1ON = 1;           // start Timer1
    PIE1bits.TMR1IE = 1;            // enable Timer1 interrupt
    
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts     
           
                 
    /*** Main loop ***/ 
    for (;;)
    {
        // display current seconds count
        set7seg(t1_secs);           // (t1_secs is updated by Timer1 interrupt)
        
        // test for enter standby mode
        if (!BUTTON)                // if button pressed (low)
        {
            LATA = 0;               //   turn off display
            LATC = 0;
            DbnceHi(BUTTON);        //   wait for stable button release
            IOCAF = 0;              //   clear all IOC flags (clears port change flag)
            do                      //   sleep until button press
            {                       
                SLEEP();    
                // if we get here, we've been woken by Timer1 or button press,
                // so go back to sleep unless the button is pressed
            }
            while (BUTTON);
            // button pressed, so stay awake
            DbnceHi(BUTTON);        //   wait for stable button high (= up)
        }        
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // Service all triggered interrupt sources 
    
    if (PIR1bits.TMR1IF)
    {    
        // *** Service Timer1 interrupt
        //
        //  TMR1 overflows every 1 sec 
        //
        //  Handles background time keeping:
        //  Each interrupt advances current count by 1 sec    
        //
        //  (only Timer1 interrupts are enabled)
        //
        PIR1bits.TMR1IF = 0;        // clear interrupt flag

        // add offset to Timer1 for overflow after 1 sec
        TMR1H |= 1<<7;              // set TMR1<15>
                                    //  (equivalent to adding 0x8000)
            
        // increment seconds count by 1
        if (++t1_secs == 10)        // when count reaches 10, 
            t1_secs = 0;            //   reset it to 0
    }
    
    if (INTCONbits.IOCIF)
    {
        // *** Service port change interrupt
        //
        //   interrupt-on-change is enabled
        //   only to allow wake-up from sleep on a button press,
        //   so do nothing in the interrupt handler  
        //
        IOCAF = 0;              //   clear all IOC flags (clears interrupt flag)
    }    
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011    // 9
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    }; 
    
    // lookup pattern bits and output them (via port latch registers)
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}