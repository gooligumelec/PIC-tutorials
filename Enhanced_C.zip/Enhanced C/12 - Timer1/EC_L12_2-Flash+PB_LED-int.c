/************************************************************************
*                                                                       *
*   Filename:      EC_L12_2-Flash+PB_LED-int.c                          *
*   Date:          2/12/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 2                                *
*                                                                       *
*   Demonstrates use of Timer1 interrupt to perform a background task   *
*   while main loop performs other actions                              *
*                                                                       *
*   One LED simply flashes at 1 Hz (50% duty cycle).                    *
*   The other LED is only lit when the pushbutton is pressed            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*       RA1 = "button pressed" indicator LED                            *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA0      // flashing LED on RA0
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED on RA1
#define BUTTON  PORTAbits.RA3       // pushbutton on RA3 (active low)


/***** CONSTANTS *****/
#define FlashMS 500                     // LED flash toggle time in milliseconds
#define InitT1  65536-FlashMS*1000/8    // Initial value to load into TMR1 to generate
                                        //   FlashMS delay (assuming 8 us/tick)


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATA = 0;                       // start with all output pins low (all LEDs off)
    TRISA = 0b111100;               // configure led pins (RA0+RA1) as outputs
                                    // (RA3 is an input)
                                    
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz                                    
    
    // configure Timer1
    T1CONbits.TMR1CS = 0b00;        // use instruction clock          
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
                                    //  -> increment TMR1 every 8 us
    T1CONbits.TMR1ON = 0;           // stop Timer1                                    
    TMR1 = InitT1;                  // load TMR1 with initial value (InitT1)
                                    //   to overflow after 500 ms     
    T1CONbits.TMR1ON = 1;           // start Timer1 
    PIR1bits.TMR1IF = 0;            // clear Timer1 interrupt flag  
    PIE1bits.TMR1IE = 1;            // enable Timer1 interrupt
            
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts  
    
                 
    /*** Main loop ***/
    for (;;)
    {
        // respond to button press
        B_LED = ~BUTTON;            // turn on indicator only if button pressed
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // *** Service Timer1 interrupt
    //
    //  TMR1 overflows every 500 ms (approx)
    //
    //  Flashes LED at ~1 Hz by toggling on each interrupt
    //      (every ~500 ms)    
    //
    //  (only Timer1 interrupts are enabled)
    //
    PIR1bits.TMR1IF = 0;            // clear interrupt flag
    
    // add offset to Timer1 for overflow after 500 ms
    T1CONbits.TMR1ON = 0;           // stop Timer1  
    TMR1 += InitT1+5;               // add 16-bit offset (initial value 
                                    //  adjusted for addition overhead) to TMR1
                                    //  to generate ~500 ms count
    T1CONbits.TMR1ON = 1;           // start Timer1

    // toggle flashing LED
    F_LED = ~F_LED; 
}