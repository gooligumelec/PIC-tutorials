/************************************************************************
*                                                                       *
*   Filename:      EC_L12_7d-TMR1_gate-single.c                         *
*   Date:          3/12/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 7d                               *
*                                                                       *
*   Demonstrates use of Timer1 gate control                             *
*   to measure the pulse width of a digital signal on /T1G,             *
*   scaled and displayed as a single hex digit                          *
*                                                                       *
*   Timer1 is used to time (in microseconds) every high pulse on /T1G.  *
*   Result is divided by 256 and displayed in hex on a single-digit     *
*   7-segment LED display.                                              *
*   Time base is internal RC oscillator.                                *
*                                                                       *
*   (version using single-pulse mode)                                   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       /T1G (RA4)   = signal to measure pulse width of                 *
*                      (active high, 4 ms max)                          * 
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATA = 0;                       // start with all output pins low 
    LATC = 0;                       //   (all LED segments off)
    TRISA = 1<<4;                   // configure PORTA and PORTC as all outputs
    TRISC = 0;                      //   except RA4 (/T1G input)
    ANSELA = 0;                     // no analog inputs (/T1G is a digital input)

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1011;       // internal oscillator = 1 Mhz
                                    // -> 1 us / processor cycle 
        
    // configure Timer1
    T1CONbits.TMR1CS = 0b01;        // use processor clock  
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable Timer1        
    T1GCONbits.TMR1GE = 1;          // gate enabled
    T1GCONbits.T1GSS = 00;          // gate source is /T1G pin    
    T1GCONbits.T1GPOL = 1;          // gate is active high
    T1GCONbits.T1GTM = 0;           // toggle mode disabled
    T1GCONbits.T1GSPM = 1;          // single-pulse mode enabled
    T1GCONbits.T1GGO_nDONE = 0;     // single-pulse acquisition disabled
                                    //  -> increment TMR1 every 1 us,
                                    //     gated by active high single pulses on /T1G    
    
                 
    /*** Main loop ***/ 
    for (;;)
    {
        // Measure width of pulses on /T1G input
        
        // clear Timer1
        TMR1 = 0;              
        
        // acquire a single pulse 
        T1GCONbits.T1GGO = 1;           // begin single-pulse acquisition
        while (T1GCONbits.T1GGO_nDONE)  // wait for end of pulse
            ;                           // (indicated by T1GGO/nDONE flag clear)
        
        // display scaled Timer1 count (divide by 256)         
        set7seg(TMR1/256 & 0x0f);    // display low nybble of TMR1/256
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011,   // 9
        0b000111,   // A
        0b000111,   // b
        0b000110,   // C
        0b000101,   // d
        0b000111,   // E
        0b000111    // F 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F 
    }; 
    
    // lookup pattern bits and output them (via port latch registers)
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}