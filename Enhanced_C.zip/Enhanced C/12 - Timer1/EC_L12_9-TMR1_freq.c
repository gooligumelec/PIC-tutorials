/************************************************************************
*                                                                       *
*   Filename:      EC_L12_9-TMR1_freq.c                                 *
*   Date:          3/12/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 9                                *
*                                                                       *
*   Demonstrates use of Timer0 overflow gating                          *
*   to measure the frequency of a digital signal on T1CKI,              *
*   scaled and displayed as a single hex digit                          *
*                                                                       *
*   Timer1 is used to count every high pulse on T1CKI                   *
*   while being gated by successive Timer0 overflows (262 ms apart)     *
*   Result is divided by 256 and displayed in hex on a single-digit     *
*   7-segment LED display.                                              *
*   Time base for Timer0 is internal RC oscillator.                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       T1CKI        = signal to measure frequency of (15.6 kHz max)    *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATA = 0;                       // start with all output pins low 
    LATC = 0;                       //   (all LED segments off)
    TRISA = 1<<5;                   // configure PORTA and PORTC as all outputs
    TRISC = 0;                      //   except RA5 (T1CKI input)

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
                                    // -> 8 us / instruction cycle

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b110;      // prescale = 128
                                    // -> increment TMR0 every 1024 us 
                                    // -> TMR0 overflows every 262 ms  
        
    // configure Timer1
    T1CONbits.TMR1CS = 0b10;        // external clock  
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable Timer1        
    T1GCONbits.TMR1GE = 1;          // gate enabled
    T1GCONbits.T1GSS = 01;          // gate source is Timer0 overflow    
    T1GCONbits.T1GPOL = 1;          // gate is active high
    T1GCONbits.T1GTM = 1;           // toggle mode enabled
    T1GCONbits.T1GSPM = 0;          // single-pulse mode disabled
                                    //  -> signal on T1CKI clocks TMR1,
                                    //     gate toggles after each Timer0 overflow    
    
                 
    /*** Main loop ***/ 
    for (;;)
    {
        // Measure frequency of signal on T1CKI input
        // (assume gate control is low at start of loop)
        
        // clear Timer1
        TMR1 = 0;              
        
        // wait while gate is active (= one Timer0 period = 262 ms) 
        while (!T1GCONbits.T1GVAL)  // wait for gate value to go high
            ;
        while (T1GCONbits.T1GVAL)   // wait for gate value to go low
            ;   
        
        // display scaled Timer1 count (divide by 256)         
        set7seg(TMR1/256 & 0x0f);    // display low nybble of TMR1/256
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011,   // 9
        0b000111,   // A
        0b000111,   // b
        0b000110,   // C
        0b000101,   // d
        0b000111,   // E
        0b000111    // F 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F 
    }; 
    
    // lookup pattern bits and output them (via port latch registers)
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}