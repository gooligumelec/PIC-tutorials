/************************************************************************
*                                                                       *
*   Filename:      EC_L4_4-Flash_LED_XTAL.c                             *
*   Date:          5/2/14                                               *
*   File Version:  1.3                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 4, example 4                                 *
*                                                                       *
*   Demonstrates use of Timer0 in counter mode                          *
*                                                                       *
*   LED flashes at 1 Hz (50% duty cycle),                               *
*   with timing derived from 32.768 kHz input on T0CKI                  *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1   = flashing LED                                            *
*       T0CKI = 32.768 kHz signal                                       *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define FLASH  LATAbits.LATA1       // flashing LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port   
    LATA = 0;                       // start with all output pins low (LED off)     
    TRISA = 0b111101;               // configure RA1 (only) as an output
    ANSELA = 0;                     // disable analog input mode for all pins
                                    //  -> T0CKI(RA2) is a digital input
    
    // configure Timer0
    OPTION_REGbits.TMR0CS = 1;      // select counter mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b110;      // prescale = 128
                                    // -> increment at 256 Hz with 32.768 kHz input
                                    
                 
    //*** Main loop
    for (;;)
    {
        // TMR0<7> cycles at 1 Hz, so continually copy to LED
        FLASH = (TMR0 & 1<<7) != 0;     // FLASH = TMR0<7>
    } 
}
