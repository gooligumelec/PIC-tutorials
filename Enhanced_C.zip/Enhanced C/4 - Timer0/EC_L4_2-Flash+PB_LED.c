/************************************************************************
*                                                                       *
*   Filename:      EC_L4_2-Flash+PB_LED.c                               *
*   Date:          3/2/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 4, example 2                                 *
*                                                                       *
*   Demonstrates use of Timer0 to maintain timing of background tasks   *
*   while performing other actions in response to changing inputs       *
*                                                                       *
*   One LED simply flashes at 1 Hz (50% duty cycle).                    *
*   The other LED is only lit when the pushbutton is pressed            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*       RA1 = "button pressed" indicator LED                            *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define FLASH  LATAbits.LATA0       // flashing LED
#define PRESS  LATAbits.LATA1       // "button pressed" indicator LED

#define BUTTON  PORTAbits.RA3       // pushbutton


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation

    // configure port
    LATA = 0;                   // start with all output pins low (LEDs off)
    TRISA = 0b111100;           // configure RA0 and RA1 (only) as outputs
                                // (RA3 is an input) 

    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b111;      // prescale = 256
                                    // -> increment TMR0 every 2048 us


    //*** Main loop
    for (;;)
    {
        // delay 500 ms
        TMR0 = 0;
        while (TMR0 < (int)(500/2.048)) // repeat for 500 ms (2.048 ms/count)
        {
            PRESS = ~BUTTON;            //  turn on indicator only if button pressed 
        }                
             
        // toggle flashing LED
        FLASH = ~FLASH;
    }  
}