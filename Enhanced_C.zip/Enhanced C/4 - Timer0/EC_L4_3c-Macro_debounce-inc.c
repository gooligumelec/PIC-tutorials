/************************************************************************
*                                                                       *
*   Filename:      EC_L4_3c-Macro_debounce-inc.c                        *
*   Date:          5/2/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-enh.h     (provides debounce macros)      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 4, example 3c                                *
*                   Toggles LED when button is pressed                  *
*                                                                       *
*   Demonstrates use of debounce macro defined in an include file       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = LED                                                       *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>

#include "stdmacros-enh.h"  // DbnceHi() - debounce switch, wait for high
                            //  (requires TMR0 running at 64 us/tick)

/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATAbits.LATA1      // indicator LED
#define BUTTON  PORTAbits.RA3       // pushbutton


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = 0b111101;           // configure RA1 (only) as an output
                                // (RA3 is an input) 
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    // -> increment TMR0 every 64 us


    //*** Main loop 
    for (;;)
	{
        // wait for button press
        while (BUTTON == 1)         // wait until button low
            ;
        
        // toggle LED
        LED = ~LED;   

        // wait for button release
        DbnceHi(BUTTON);            // wait until button high (debounced)
    }   
}

