/************************************************************************
*                                                                       *
*   Filename:      EC_L14_7-ADC_hex-out-CCP.c                           *
*   Date:          12/6/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.34 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 14, example 7                                *
*                                                                       *
*   Demonstrates use of CCP compare mode special event trigger          *
*   to schedule periodic ADC measurements                               *
*                                                                       *
*   Displays ADC output in hexadecimal on 7-segment LED displays        *
*                                                                       *
*   Regularly samples analog input, using CCP special event trigger,    *
*   displaying result as 2 x hex digits on multiplexed 7-seg displays   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = digit 1 ("tens") enable (active high)         *
*       RA5             = digit 2 (ones) enable                         *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define DIG1_EN         LATCbits.LATC5      // digit 1 ("tens") digit enable
#define DIG2_EN         LATAbits.LATA5      // digit 2 (ones) digit enable
 
 
/***** CONSTANTS *****/
#define ADCPeriod   10000               // ADC sample period in microseconds
                                        //   (max 65535)    

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSELAbits.ANSA2 = 1;           // select analog mode for RA2
                                    //  -> RA2/AN2 is an analog input
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1011;       // internal oscillator = 1 MHz
                                    //  -> Tosc = 1 us, 4 us / instruction cycle

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b000;      // prescale = 2
                                    //  -> increment TMR0 every 8 us
                                    //  -> TMR0 overflows every 2.048 ms  
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt            
    
    // configure Timer1
    T1CONbits.TMR1CS = 0b01;        // use processor clock          
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 1 us                              
                                    
    // configure ADC     
    ADCON1bits.ADCS = 0b000;        // Tad = 2*Tosc = 2 us (with Fosc = 1 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00010;       // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on
    PIE1bits.ADIE = 1;              // enable ADC interrupt  
    
    // initialise CCP4 module
    CCPR4 = ADCPeriod;              // compare vslue = ADC sample period
    CCP4CONbits.CCP4M = 0b1011;     // special trigger mode
                                    //  -> sample ADC and reset TMR1 on match

    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral interrupts
    ei();                           // enable global interrupts  
    
            
    /*** Main loop ***/
    for (;;)
    {
        ;                           // do nothing      
    }
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
                                        // current ADC result (in hex):
    static uint8_t  dig1 = 0;           //   digit 1 ("tens" - most significant)
    static uint8_t  dig2 = 0;           //   digit 2 ("ones" - least significant)
 
    // Service all triggered interrupt sources
    
    if (INTCONbits.TMR0IF)
    {   
        // *** Service Timer0 interrupt
        //
        //  TMR0 overflows every 2.048 ms
        //
        //  Displays current ADC result (in hex) on 7-segment displays
        //
        INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
        // Display current ADC result (in hex) on 2 x 7-segment displays
        //   mpx_cnt determines current digit to diplay
        //
        switch (mpx_cnt)
        {
            case 0:
                // display digit 1
                set7seg(dig1);                  // output digit 1  
                DIG1_EN = 1;                    // enable digit 1 display
                break;
                
            case 1:
                // display digit 2
                set7seg(dig2);                  // output digit 2  
                DIG2_EN = 1;                    // enable digit 2 display
                break;
        }
        // Increment mpx_cnt, to select next digit for next time
        mpx_cnt++;
        if (mpx_cnt == 2)       // reset count if at end of digit sequence
            mpx_cnt = 0;
    }  
    
    if (PIR1bits.ADIF)
    {
        // *** Service ADC interrupt
        //
        //  Conversion is initiated by CCP special event trigger,
        //  every ADCPeriod microseconds
        //
        PIR1bits.ADIF = 0;                      // clear interrupt flag
        // copy ADC result to display variables
        //  (to be displayed by Timer0 handler)
        dig1 = ADRESH >> 4;     // get digit 1 from high nybble of ADRESH        
        dig2 = ADRESH & 0x0F;   // get digit 2 from low nybble of ADRESH        
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011,   // 9 
        0b010011,   // A
        0b010011,   // b
        0b010010,   // C
        0b010001,   // d
        0b010011,   // E
        0b010011    // F           
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // disable displays
    LATA = 0;               // clear all digit enable lines on PORTA
    LATC = 0;               //  and PORTC
    
    // lookup and output digit pattern
    LATA = pat7segA[digit];     
    LATC = pat7segC[digit];
}
