/************************************************************************
*                                                                       *
*   Filename:      EC_L14_4a-flash_LED-50p-CCP.c                        *
*   Date:          11/6/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.34 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 14, example 4a                               *
*                                                                       *
*   Demonstrates use of CCP compare mode                                *
*   to toggle the CCP2 pin                                              *
*                                                                       *
*   Flashes an LED on CCP2 at 1 Hz, with 50% duty cycle                 *
*   Time base is internal RC oscillator at 500 kHz.                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP2 = indicator LED                                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<3);                // configure PORTC as all inputs
                                    //   except RC3 (CCP2 output)
  
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz 
                                    //  -> 8 us / instruction cycle
      
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1CS = 0b00;        // use instruction clock          
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 8 us

    // configure ECCP2 module
    CCPR2 = 500000/8;               // initial compare time = 0.5 s /8 us/count
    CCP2CONbits.CCP2M = 0b0010;     // compare mode, toggle CCP2 on match
                                    // (CCP2 initially low)
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Toggle CCP2 output every 0.5 sec

        // wait for CCP match
        PIR2bits.CCP2IF = 0;        // clear CCP2 interrupt flag       
        while (!PIR2bits.CCP2IF)    // wait for flag to go high
            ;

        // add 0.5 sec to last compare time        
        CCPR2 += 500000/8;          // add 0.5 sec / 8 us/count
    } 
}
