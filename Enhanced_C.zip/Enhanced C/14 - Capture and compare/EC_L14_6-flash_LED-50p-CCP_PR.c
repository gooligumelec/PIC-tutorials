/************************************************************************
*                                                                       *
*   Filename:      EC_L14_6-flash_LED-50p-CCP_PR.c                      *
*   Date:          12/6/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.34 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 14, example 6                                *
*                                                                       *
*   Demonstrates use of CCPRx as a period register for Timer1           *
*                                                                       *
*   Flashes an LED at 1 Hz, with 50% duty cycle                         *
*   Time base is internal RC oscillator at 500 kHz.                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATCbits.LATC0          // flashing LED on RC0
#define nF_LED  0                       //  (port bit 0)


/***** CONSTANTS *****/
#define FlashMS     500                 // LED flash toggle time in milliseconds
                                        //   (max 524 ms)
#define T1Period    FlashMS*1000/8      // number of Timer1 counts to generate
                                        //   FlashMS delay (assuming 8 us/tick)


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATC = 0;                       // start with all output pins low (LED off)
    TRISC = ~(1<<nF_LED);           // configure LED pin (only) as an output
  
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz 
                                    //  -> 8 us / instruction cycle
      
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1CS = 0b00;        // use instruction clock          
    T1CONbits.T1CKPS = 0b00;        // no prescaler 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 8 us

    // initialise CCP3 module
    CCPR3 = T1Period;               // load compare vslue (= TMR1 period)
    CCP3CONbits.CCP3M = 0b1011;     // special trigger mode (reset TMR1 on match)
    PIE3bits.CCP3IE = 1;            // enable CCP3 interrupt

    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral interrupts
    ei();                           // enable global interrupts        
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service CCP3 interrupt
    //
    //  Triggered when TMR1 matches CCPR3
    //      (every 500 ms)
    //
    //  Flashes LED at 1 Hz by toggling on each interrupt
    //
    //  (only CCP3 interrupts are enabled)   
    //   
    PIR3bits.CCP3IF = 0;        // clear interrupt flag
    
    // toggle flashing LED
    F_LED = ~F_LED;     
}