/************************************************************************
*                                                                       *
*   Filename:      EMC_L5_1d-Comp1_COUT+hyst.c                          *
*   Date:          11/6/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 5, example 1d                      *
*                                                                       *
*   Demonstrates use of Comparator 1 hysteresis                         *
*                                                                       *
*   Turns on LED when voltage on C1IN+ < (voltage on C12IN0- - Vhy)     *
*   Turns off LED when voltage on C1IN+ > (voltage on C12IN0- + Vhy)    *
*   (LED driven directly by C1OUT pin, Vhy ~ 45 mV)                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       C1IN+   = voltage to be measured (e.g. pot output or LDR)       *
*       C12IN0- = threshold voltage (set by voltage divider resistors)  *
*       C1OUT   = indicator LED                                         *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure ports
    TRISA = 0b111011;           // configure RA2/C1OUT (only) as an output
                                // (RA0/C1IN+ and RA1/C12IN0- are inputs)
    ANSELAbits.ANSA0 = 1;       // select analog mode for RA0 and RA1  
    ANSELAbits.ANSA1 = 1;       //  -> RA0/C1IN+ and RA1/C12IN0- are analog inputs             
    
    // configure comparator 1
    CM1CON0bits.C1ON = 1;       // comparator enabled
    CM1CON0bits.C1OE = 1;       // external output enabled
    CM1CON0bits.C1POL = 1;      // output inverted
    CM1CON0bits.C1SP = 1;       // normal power mode
    CM1CON0bits.C1HYS = 1;      // hysteresis enabled
    CM1CON0bits.C1SYNC = 0;     // asynchronous output    
    CM1CON1bits.C1PCH = 0b00;   // + in = C1IN+ pin
    CM1CON1bits.C1NCH = 0b00;   // - in = C12IN0- pin
                                //  -> C1OUT pin = 1 if C1IN+ < (C12IN0- - Vhy)
                                
    
    /*** Main loop ***/
    for (;;)
    {
        ;   // (do nothing)             
    }
}
