/************************************************************************
*                                                                       *
*   Filename:      EMC_L6_1-ADC_4LEDs.c                                 *
*   Date:          22/8/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 6, example 1                       *
*                                                                       *
*   Demonstrates basic use of ADC                                       *
*                                                                       *
*   Continuously samples analog input, copying value to 4 x LEDs        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN0     = voltage to be measured (e.g. pot output or LDR)       *
*       RC0-3   = output LEDs (RC3 is MSB)                              *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure ports
    TRISC = 0;                      // PORTC is all outputs (PORTA all inputs)
    ANSELAbits.ANSA0 = 1;           // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
        
    // configure ADC     
    ADCON1bits.ADCS = 0b000;        // Tad = 2*Tosc = 4 us (with Fosc = 500 kHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    
    /*** Main loop ***/
    for (;;)
    {
        // sample analog input
        __delay_us(10);                 // wait 10 us (acquisition time)
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;
        
        // display result on 4 x LEDs
        LATC = ADRESH >> 4;         // copy high four bits of result
                                    //   to low nybble of output port (LEDs)
    }
}
