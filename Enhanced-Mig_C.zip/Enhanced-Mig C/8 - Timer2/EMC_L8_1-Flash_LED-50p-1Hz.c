/************************************************************************
*                                                                       *
*   Filename:      EMC_L8_1-Flash_LED-50p-1Hz.c                         *
*   Date:          11/1/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.32 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 8, example 1                       *
*                                                                       *
*   Demonstrates use of Timer4 to generate a specific time-base         *
*   for an interrupt-driven background task                             *
*                                                                       *
*   Flash an LED at exactly 1 Hz (50% duty cycle).                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATCbits.LATC0          // flashing LED on RC0


/***** CONSTANTS *****/
#define FlashMS     500                 // LED flash toggle time in milliseconds


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATC = 0;                       // start with all output pins low (LED off)
    TRISC = 0b111110;               // configure only led pin (RC0) as an output    

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz
                                    //  -> 1 us / instruction cycle
        
    // configure Timer4
    PR4 = 249;                      // Timer4 period = 250 clocks (PR4 = period-1)
    T4CONbits.T4CKPS = 0b10;        // prescale = 16
    T4CONbits.T4OUTPS = 4;          // postscale = 5 (T4OUTPS = postscale-1)
                                    //  -> increment TMR4 every 16 us,
                                    //     match PR4 every  = 4 ms (16 us x 250)
                                    //     set TMR4IF every 20 ms (4 ms x 5)
    T4CONbits.TMR4ON = 1;           // enable Timer4
    PIE3bits.TMR4IE = 1;            // enable Timer4 interrupt    
          
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts  

                                    
    /*** Main loop ***/
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  cnt_20ms = 0;   // counts 20 ms periods
    
    // *** Service Timer4 interrupt
    //
    //  Runs every 20 ms
    //    (every 5th TMR4/PR4 match;
    //     TMR4 matches PR4 every 250 x 16 us = 4000 us)
    //
    //  Flashes LED at 1 Hz 
    //    by toggling on every 25th interrupt (every 500 ms)  
    //
    //  (only Timer4 interrupts are enabled)
    //
    PIR3bits.TMR4IF = 0;            // clear interrupt flag
    
    // toggle LED every 500 ms
    ++cnt_20ms;                     // increment 20 ms period count
    if (cnt_20ms == FlashMS/20)     // if we've counted for 500 ms,
    {     
        cnt_20ms = 0;               //   reset count
        F_LED = ~F_LED;             //   toggle flashing LED 
    }
}
