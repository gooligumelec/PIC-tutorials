/************************************************************************
*                                                                       *
*   Filename:      EMC_L1_4-Toggle_LED-int-pu.c                         *
*   Date:          30/11/13                                             *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.21 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 1, example 4                       *
*                                                                       *
*   Demonstrates use of internal pullups plus debouncing                *
*                                                                       *
*   Toggles LED when pushbutton is pressed then released,               *
*   using a counting algorithm to debounce switch                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = LED                                                       *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF
 
#define _XTAL_FREQ  500000          // oscillator frequency for _delay() 
            

/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     db_cnt;             // debounce counter
    
    //*** Initialisation

    // configure port
    LATA = 0;                       // start with all output pins low (LED off)    
    TRISA = ~(1<<1);                // configure RA1 (only) as an output
    OPTION_REGbits.nWPUEN = 0;      // enable weak pull-ups (global)
    WPUA = 1<<3;                    // enable pull-up on RA3 only

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz


    //*** Main loop
    for (;;)
    {
        // wait for button press
        while (PORTAbits.RA3 == 1)  // wait until RA3 low
            ;

        // toggle LED on RA1
        LATAbits.LATA1 = ~LATAbits.LATA1;

        // wait for button release, debounce by counting:
        for (db_cnt = 0; db_cnt <= 10; db_cnt++)
        {
            __delay_ms(1);          // sample every 1 ms
            if (PORTAbits.RA3 == 0) // if button down (RA3 low)
                db_cnt = 0;         //   restart count
        }                           // until button up for 10 successive reads
    } 
}