/************************************************************************
*                                                                       *
*   Filename:      EMC_L1_2-Flash_LED.c                                 *
*   Date:          20/11/13                                             *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.21 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 1, example 2                       *
*                                                                       *
*   Flashes an LED at approx 1 Hz.                                      *
*   LED continues to flash until power is removed.                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation

    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = ~(1<<1);            // configure RA1 (only) as an output

    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz


    //*** Main loop
    for (;;)
    {
        // toggle LED on RA1
        LATAbits.LATA1 = ~LATAbits.LATA1;

        // delay 500 ms
        __delay_ms(500);

    }   // repeat forever
}