/************************************************************************
*                                                                       *
*   Filename:      EMC_L4_2-Flash_LED-XT_16M.c                          *
*   Date:          4/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 4, example 2                       *
*                                                                       *
*   Demonstrates use of XT oscillator mode with 4xPLL                   *
*   (using 4 MHz crystal or resonator + 4xPLL = 16 MHz clock)           *
*                                                                       *
*   Flash an LED at exactly 1 Hz (50% duty cycle).                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC1         = flashing LED                                      *
*       OSC1, OSC2  = 4.00 MHz crystal (or resonator)                   *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, XT oscillator (no clock out), 4xPLL on
#pragma config MCLRE = ON, FOSC = XT, CLKOUTEN = OFF, PLLEN = ON
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATCbits.LATC1      // flashing LED


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATC = 0;                   // start with all output pins low (LED off)
    TRISC = 0b111101;           // configure RC1 (only) as an output

    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 1;         // no prescaling
                                    //  -> increment TMR0 every 0.25 us
                                    //     (assuming 16 MHz clock)
             
    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts
                                    
                                    
    /*** Main loop ***/
    for (;;)
    {
        ;   // (do nothing)
    }
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint16_t  cnt_t0 = 0;    // counts timer0 overflows
    
    //*** Service Timer0 interrupt
    //
    //  TMR0 overflows every 250 clocks = 62.5 us
    //
    //  Flashes LED at 1 Hz by toggling on every 8000th interrupt
    //      (every 500 ms)   
    // 
    //   (only Timer0 interrupts are enabled)
    //
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    TMR0 += 256-250+3;              // add value to Timer0
                                    //   for overflow after 250 counts    
    
    // toggle LED every 500 ms
    ++cnt_t0;                       // increment interrupt count (every 62.5 us) 
    if (cnt_t0 == 8000)             // if count overflow (every 500 ms)
    {
        cnt_t0 = 0;                 //   reset count
        F_LED = ~F_LED;             //   toggle LED      
    } 
}
