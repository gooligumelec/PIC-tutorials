/************************************************************************
*                                                                       *
*   Filename:      EMC_L4_1a-Flash_LED-IntRC_8M+PLL.c                   *
*   Date:          4/5/14                                               *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 4, example 1a                      *
*                                                                       *
*   Demonstrates use of 4xPLL via software enable                       *
*                                                                       *
*   Flashes an LED at approx 1 Hz using internal 8 MHz RC oscillator    *
*   4xPLL is enabled whenever pushbutton is pressed                     *
*       -> flash at 4 Hz while pushbutton pressed                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC1 = indicator LED                                             *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  8000000     // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define FLASH   LATCbits.LATC1      // flashing LED
#define BUTTON  PORTAbits.RA3       // pushbutton (active low)


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    LATC = 0;                   // start with all output pins low (LED off)
    TRISC = 0b111101;           // configure RC1 (only) as an output
    
    // configure oscillator
    OSCCONbits.SCS = 0b00;      // clock source = config word (= INTOSC)
    OSCCONbits.IRCF = 0b1110;   // internal oscillator = 8 MHz
    OSCCONbits.SPLLEN = 0;      // 4xPLL disabled    

    
    /*** Main loop ***/
    for (;;)  
    {       
        // enable 4xPLL only if button pressed
        OSCCONbits.SPLLEN = ~BUTTON;    // SPLLEN = 1 only if button pressed
        
        // delay 500 ms
        __delay_ms(500);   
             
        // toggle LED
        FLASH = ~FLASH;        
    }
}
