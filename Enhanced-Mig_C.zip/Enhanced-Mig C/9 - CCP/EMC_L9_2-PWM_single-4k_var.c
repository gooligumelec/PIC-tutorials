/************************************************************************
*                                                                       *
*   Filename:      EMC_L9_2-PWM_single-4k_var.c                         *
*   Date:          6/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 9, example 2                       *
*                                                                       *
*   Demonstrates varying single-output PWM duty cycle                   *
*                                                                       *
*   Outputs PWM signal (~3906 Hz) on CCP4                               *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP4 = PWM output (e.g. LED or motor)                           *
*       AN0  = analog input (e.g. pot or LDR)                           *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<1);                // configure PORTC as all inputs
                                    //   except RC1 (CCP4 output)
    ANSELA = 1<<0;                  // select analog mode for RA0
                                    //  -> RA0/AN0 is an analog input

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b1101;       // internal oscillator = 4 MHz 
                                    //  -> 1 us / instruction cycle
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2 us (with Fosc = 4 MHz) 
    ADCON1bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON1bits.ADNREF = 0;          // Vref- is Vss
    ADCON1bits.ADPREF = 0b00;       // Vref+ is Vdd
    ADCON0bits.CHS = 0b00000;       // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // select PWM timer
    CCPTMRSbits.C4TSEL = 0b10;      // use Timer6 with CCP4
    // configure Timer6
    T6CONbits.T6CKPS = 0b00;        // prescale = 1 
    T6CONbits.TMR6ON = 1;           // enable timer
                                    //  -> TMR6 increments every 1 us
    PR6 = 255;                      // period = 256 x 1 us = 256 us
                                    //  -> PWM frequency = 3906 Hz
    // configure CCP4
    CCP4CONbits.DC4B = 0b00;        // LSBs of PWM duty cycle = 00
    CCP4CONbits.CCP4M = 0b1100;     // select PWM mode               
                                    //  -> single PWM output on CCP4

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;              // start conversion
        while (ADCON0bits.GO_nDONE)     // wait until done
            ;

        // set new PWM duty cycle
        CCPR4L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
