/************************************************************************
*                                                                       *
*   Filename:      EMC_L9_1b-flash_LED-20p-CCP.c                        *
*   Date:          6/11/15                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     16F1824                                              *
*   Compiler:      MPLAB XC8 v1.35 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 9, example 1b                      *
*                                                                       *
*   Demonstrates use of CCP compare mode                                *
*   to generate high and low pulses on the CCP2 pin                     *
*                                                                       *
*   Flashes an LED on CCP2 at 1 Hz, with 20% duty cycle                 *
*   Time base is internal RC oscillator at 500 kHz.                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP2 = indicator LED                                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), 4xPLL off
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, PLLEN = OFF
//  no watchdog timer, brownout resets enabled, low brownout voltage
#pragma config WDTE = OFF, BOREN = ON, BORV = LO
//  no power-up timer, no failsafe clock monitor, two-speed start-up disabled
#pragma config PWRTE = OFF, FCMEN = OFF, IESO = OFF
//  no code or data protect, no write protection
#pragma config CP = OFF, CPD = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<3);                // configure PORTC as all inputs
                                    //   except RC3 (CCP2 output)
  
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz 
                                    //  -> 8 us / instruction cycle
      
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1CS = 0b00;        // use instruction clock          
    T1CONbits.T1CKPS = 0b01;        // prescale = 2 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 16 us

    // initialise ECCP2 module
    CCPR2 = 0;                      // initial compare time = 0
                                    // (note: CCP initially off, CCP2 output low)
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Output low for 0.8 sec
        
        // add 0.8 sec to previous compare time        
        CCPR2 += 800000/16;             // add 0.8 sec / 16 us/count  
        
        // configure ECCP2 to set CCP2 when compare time reached       
        CCP2CONbits.CCP2M = 0b1000;     // compare mode, set CCP2 on match
        
        // wait for CCP match
        PIR2bits.CCP2IF = 0;        // clear CCP2 interrupt flag       
        while (!PIR2bits.CCP2IF)    // wait for flag to go high
            ;
            
            
        // Output high for 0.2 sec
        
        // add 0.2 sec to previous compare time        
        CCPR2 += 200000/16;             // add 0.2 sec / 16 us/count  
        
        // configure ECCP2 to clear CCP2 when compare time reached       
        CCP2CONbits.CCP2M = 0b1001;     // compare mode, clear CCP2 on match
        
        // wait for CCP match
        PIR2bits.CCP2IF = 0;        // clear CCP2 interrupt flag       
        while (!PIR2bits.CCP2IF)    // wait for flag to go high
            ;
    } 
}
