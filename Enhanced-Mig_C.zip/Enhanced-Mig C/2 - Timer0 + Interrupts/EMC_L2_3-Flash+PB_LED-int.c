/************************************************************************
*                                                                       *
*   Filename:      EMC_L2_3-Flash+PB_LED-int.c                          *
*   Date:          24/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 2, example 3                       *
*                                                                       *
*   Demonstrates use of Timer0 interrupt to perform a background task   *
*   while performing other actions in repsonse to changing inputs       *
*                                                                       *
*   One LED flashes at exactly 1 Hz (50% duty cycle).                   *
*   The other LED is only lit when the pushbutton is pressed.           *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = flashing LED                                              *
*       RA1 = "button pressed" indicator LED                            *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define F_LED   LATAbits.LATA0      // flashing LED
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED

#define BUTTON  PORTAbits.RA3       // pushbutton


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                   // start with all output pins low (LED off)
    TRISA = 0b111100;           // configure RA0 and RA1 (only) as outputs
                                // (RA3 is an input) 
    
    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz
                                //  -> 8 us / instruction cycle
        
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 1;         // no prescaling
                                    //  -> increment TMR0 every 8 us   

    // enable interrupts
    INTCONbits.TMR0IE = 1;          // enable Timer0 interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        // respond to button press
        B_LED = ~BUTTON;        // turn on indicator LED only if button pressed 
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  cnt_t0 = 0;    // counts timer0 interrupts
    
    //*** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2 ms
    //
    //  Flashes LED at 1 Hz by toggling on every 250th interrupt
    //      (every 500 ms)
    //
    //  (only Timer0 interrupts are enabled)
    //    
    INTCONbits.TMR0IF = 0;          // clear interrupt flag
    
    TMR0 += 256-250+3;              // add value to Timer0
                                    //   for overflow after 250 counts    
    
    // toggle LED every 500 ms
    ++cnt_t0;                       // increment interrupt count (every 2 ms) 
    if (cnt_t0 == 500/2)            // if count overflow (every 500 ms)
    {
        cnt_t0 = 0;                 //   reset count
        F_LED = ~F_LED;             //   toggle LED      
    }          
}
