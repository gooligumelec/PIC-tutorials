/************************************************************************
*                                                                       *
*   Filename:      EMC_L2_4-Toggle_LED-ext_int.c                        *
*   Date:          25/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 2, example 4                       *
*                                                                       *
*   Demonstrates use of external interrupt (INT pin)                    *
*                                                                       *
*   Toggles LED when pushbutton on INT is pressed                       *
*    (high -> low transition)                                           *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*       INT = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                       // start with all output pins low (LED off)
    TRISA = 0b111101;               // configure RA1 (only) as an output
    ANSELA = 0;                     // disable analog input mode for all pins
                                    //  -> INT(RA2) is a digital input
                                    
    // configure external interrupt
    OPTION_REGbits.INTEDG = 0;      // trigger on falling edge 
    
    // enable interrupts
    INTCONbits.INTF = 0;            // clear external interrupt flag
    INTCONbits.INTE = 1;            // enable external interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service external interrupt
    //
    //  Triggered on high -> low transition on INT pin
    //  caused by externally debounced pushbutton press
    // 
    //  Toggles LED on every high -> low transition
    //  
    //  (only external interrupts are enabled)
    //   
    INTCONbits.INTF = 0;            // clear interrupt flag
    
    // toggle indicator LED
    B_LED = ~B_LED;                                                 
}
