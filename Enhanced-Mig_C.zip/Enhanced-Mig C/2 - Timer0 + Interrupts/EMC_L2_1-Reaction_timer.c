/************************************************************************
*                                                                       *
*   Filename:      EMC_L2_1-Reaction_timer.c                            *
*   Date:          24/2/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 2, example 1                       *
*                   Reaction Timer game.                                *
*                                                                       *
*   Demonstrates use of timer0 to time real-world events                *
*                                                                       *
*   User must attempt to press button within 200 ms of "start" LED      *
*   lighting.  If and only if successful, "success" LED is lit.         *
*                                                                       *
*       Begin with both LEDs unlit.                                     *
*       2 sec delay before lighting "start"                             *
*       (fail if button already pressed before "start" is signalled)    *
*       Clear timer then wait for button press                          *
*       If time < 200 ms, light "success"                               *
*       Turn off "start"                                                *
*       1 sec delay before waiting for button release and restarting    *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = success LED                                               *
*       RA1 = start LED                                                 *
*       RA3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


// Pin assignments
#define START   LATAbits.LATA1      // LEDs
#define SUCCESS LATAbits.LATA0

#define BUTTON  PORTAbits.RA3       // pushbutton


/***** CONSTANTS *****/
#define MAXRT   200                 // Maximum reaction time (in ms)


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation  
    
    // configure port
    LATA = 0;                   // start with all output pins low (LEDs off)    
    TRISA = 0b111100;           // configure RA0 and RA1 (only) as outputs
                                // (RA3 is an input) 
 
    // configure oscillator
    OSCCONbits.SCS1 = 1;        // select internal clock
    OSCCONbits.IRCF = 0b0111;   // internal oscillator = 500 kHz                                  
    
    // configure Timer0
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b111;      // prescale = 256
                                    // -> increment TMR0 every 2048 us


    //*** Main loop                                 
    for (;;)
    {
        // start with both LEDs off
        LATA = 0;                   

        // delay 2 sec
        __delay_ms(2000);            

        // perform reaction time test
        if (BUTTON != 0)            // if button not already pressed
        {
            // indicate start
            START = 1;               
            
            // zero timer
            TMR0 = 0;                   // clear timer0
            INTCONbits.TMR0IF = 0;      // and overflow flag
            
            // wait for button press
            while (BUTTON == 1)         // wait until button low
                ;
            
            // indicate success if elapsed time ok
            if (!INTCONbits.TMR0IF              // if timer did not overflow
              && TMR0 < (int)(MAXRT/2.048))     // and time < max (2.048 ms/count)
                {                                          
                    SUCCESS = 1;                //   turn on success LED
                }
            
            // turn off start
            START = 0;                      
        }
 
        // delay 1 sec
        __delay_ms(1000);   
        
        // wait for button release
        while (BUTTON == 0)             // wait until button high
            ;           
    }  
}
