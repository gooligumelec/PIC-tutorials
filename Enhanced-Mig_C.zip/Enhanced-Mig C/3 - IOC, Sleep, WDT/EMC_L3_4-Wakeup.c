/************************************************************************
*                                                                       *
*   Filename:      EMC_L3_4-Wakeup.c                                    *
*   Date:          18/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-enh.h     (provides debounce macros)      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 3, example 4                       *
*                                                                       *
*   Demonstrates use of interrupt-on-change for wake-up from sleep mode *
*                                                                       *
*   Toggle LED, sleeping while LED is off:                              *
*       Turn on LED, debounce pushbutton then wait for button press     *
*       turn off LED, debounce pushbutton, sleep then repeat            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*       RA3 = pushbutton (active low)                                   *
*                                                                       *
************************************************************************/

#include <xc.h>

#include "stdmacros-enh.h"  // DbnceHi() - debounce switch, wait for high
                            //  (requires TMR0 running at 64 us/tick)


/***** CONFIGURATION *****/
//  int reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = OFF, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout reset on (off in sleep), low brownout voltage, no low-power brownout reset
#pragma config BOREN = NSLEEP, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATAbits.LATA1      // indicator LED
#define BUTTON  PORTAbits.RA3       // pushbutton (active low)


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port    
    TRISA = 0b111101;               // configure RA1 (only) as an output
    
    // configure interrupt-on-change
    IOCANbits.IOCAN3 = 1;           // enable detection of falling edges on RA3 
    INTCONbits.IOCIE = 1;           // enable wake-up (interrupt) on port change           

    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz

    // configure Timer0 (for DbnceHi() macro)
    OPTION_REGbits.TMR0CS = 0;      // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    // -> increment TMR0 every 64 us
                                        
    // configure sleep mode
    VREGCONbits.VREGPM = 1;         // enable low-power sleep mode


    //*** Main loop 
    for (;;)
	{
        // turn on LED    
        LED = 1;         
                 
        // wait for stable button high
        // (in case it is still bouncing after wakeup)
        DbnceHi(BUTTON);    
           
        // wait for button press
        while (BUTTON == 1)         // wait until button low
            ;

        // go into standby (low power) mode
        LED = 0;                    // turn off LED
        DbnceHi(BUTTON);            // wait for stable button release
        IOCAF = 0;                  // clear all IOC flags (clears port change flag)
        SLEEP();                    // enter sleep mode
    }
}
