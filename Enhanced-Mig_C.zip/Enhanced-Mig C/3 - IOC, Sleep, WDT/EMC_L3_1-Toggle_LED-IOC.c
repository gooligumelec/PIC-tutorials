/************************************************************************
*                                                                       *
*   Filename:      EMC_L3_1-Toggle_LED-IOC.c                            *
*   Date:          18/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 3, example 1                       *
*                                                                       *
*   Demonstrates use of interrupt-on-change interrupts                  *
*   (without software debouncing)                                       *
*                                                                       *
*   Toggles LED when pushbutton is pressed (high -> low transition)     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*       RA2 = pushbutton (externally debounced, active low)             *
*                                                                       *
************************************************************************/

#include <xc.h>


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clock out), no watchdog timer
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define B_LED   LATAbits.LATA1      // "button pressed" indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                       // start with all output pins low (LED off)
    TRISA = 0b111101;               // configure RA1 (only) as an output
    ANSELA = 0;                     // disable analog input mode for all pins
                                    //  -> RA2 is a digital input
                                    
    // configure interrupt-on-change                                    
    IOCANbits.IOCAN2 = 1;           // enable detection of falling edges on RA2
    
    // enable interrupts
    INTCONbits.IOCIE = 1;           // enable IOC interrupt
    ei();                           // enable global interrupts

                                    
    //*** Main loop
    for (;;)
    {
        ;   // (do nothing)
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service port change interrupt
    //
    //  Triggered on any valid transition on IOC-enabled input pin
    //  caused by externally debounced pushbutton press
    //
    //  Toggles LED on every enabled transition (e.g. high -> low)
    //
    //  (only port change interrupts are enabled)       
    //      
    IOCAF = 0;                      // clear all IOC flags (clears interrupt flag)
    
    // toggle indicator LED
    B_LED = ~B_LED; 
}
