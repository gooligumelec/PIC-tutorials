/************************************************************************
*                                                                       *
*   Filename:      EMC_L3_5b-WDTdemo+clrwdt.c                           *
*   Date:          18/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 3, example 5b                      *
*                                                                       *
*   Demonstrates clearing the watchdog timer                            *
*                                                                       *
*   Turn on LED for 1 sec, turn off, then enter endless loop            *
*       WDT is cleared in the endless loop, so                          *
*       LED stays off, even when the watchdog is enabled                *
*   WDT warning LED is lit only if WDT reset has occurred               *
*   (will remain unlit, since WDT is being continually cleared and      *
*    therefore no WDT reset will occur                                  *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0 = WDT-reset indicator LED                                   *
*       RA1 = "flashing" LED                                            *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
#define     WATCHDOG            // define to enable watchdog timer

#ifdef WATCHDOG
    //  no watchdog timer
    #pragma config WDTE = ON
#else
    //  no watchdog timer
    #pragma config WDTE = OFF
#endif   

//  ext reset, internal oscillator (no clock out)
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define WDT     LATAbits.LATA0      // watchdog timer reset indicator LED
#define LED     LATAbits.LATA1      // "flashing" LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    LATA = 0;                       // start with all output pins low (LEDs off)
    TRISA = 0b111100;               // configure RA0 and RA1 as outputs
 
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
   
    // configure watchdog timer
    WDTCONbits.WDTPS = 0b01011;     // prescale = 65536 (-> WDT timeout = 2 sec)

    
    //*** Main code
    
    // test for WDT-timeout reset
    if (!STATUSbits.nTO)        // if WDT timeout has occurred,
        WDT = 1;                //   turn on "error" LED    
    
    // flash LED
    LED = 1;                    // turn on "flash" LED
    __delay_ms(1000);           // delay 1 sec
    LED = 0;                    // turn off "flash" LED  
    
    for (;;)                    // repeatedly clear watchdog timer forever
        CLRWDT(); 
}
