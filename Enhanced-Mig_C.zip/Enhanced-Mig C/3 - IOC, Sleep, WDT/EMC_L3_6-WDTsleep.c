/************************************************************************
*                                                                       *
*   Filename:      EMC_L3_6-WDTsleep.c                                  *
*   Date:          18/3/14                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Enhanced Mid-range PIC                               *
*   Processor:     12F1501                                              *
*   Compiler:      MPLAB XC8 v1.30 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Migration lesson 3, example 6                       *
*                                                                       *
*   Demonstrates periodic wake from sleep, using the watchdog timer     *
*                                                                       *
*   Turn on LED for 1 sec, turn off, then sleep for approx 32 sec       *
*   (LED flashes for 1 sec every 33 sec)                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA1 = indicator LED                                             *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ  500000      // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, internal oscillator (no clk out), watchdog = soft control
#pragma config MCLRE = ON, FOSC = INTOSC, CLKOUTEN = OFF, WDTE = SWDTEN
//  brownout resets enabled, low brownout voltage, no low-power brownout reset
#pragma config BOREN = ON, BORV = LO, LPBOR = OFF
//  no power-up timer, no code protect, no write protection
#pragma config PWRTE = OFF, CP = OFF, WRT = OFF
//  stack resets on, high-voltage programming
#pragma config STVREN = ON, LVP = OFF

// Pin assignments
#define LED     LATAbits.LATA1      // indicator LED


/***** MAIN PROGRAM *****/
void main()
{
    //*** Initialisation
    
    // configure port
    TRISA = 0b111101;               // configure RA1 (only) as an output
 
    // configure oscillator
    OSCCONbits.SCS1 = 1;            // select internal clock
    OSCCONbits.IRCF = 0b0111;       // internal oscillator = 500 kHz
   
    // configure watchdog timer
    WDTCONbits.WDTPS = 0b01111;     // prescale = 2^20 (-> WDT period = 32 sec)
    WDTCONbits.SWDTEN = 0;          // WDT initially off

    
    //*** Main loop
    for (;;)
    {
        // flash LED
        LED = 1;                    // turn on LED
        __delay_ms(1000);           // delay 1 sec
        LED = 0;                    // turn off LED  

        // sleep for 32 sec
        WDTCONbits.SWDTEN = 1;      // enable watchdog timer        
        SLEEP();                    // enter sleep mode (until WDT time-out)
        WDTCONbits.SWDTEN = 0;      // disable watchdog timer
    }  
}
