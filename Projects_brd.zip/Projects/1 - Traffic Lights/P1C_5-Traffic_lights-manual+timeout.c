/************************************************************************
*                                                                       *
*   Filename:      P1C_5-Traffic_lights-manual+timeout.c                *
*   Date:          25/7/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Baseline PIC                                         *
*   Processor:     10F200                                               *
*   Compiler:      MPLAB XC8 v1.20 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-XC8.h     (provides DbnceHi macro)        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Simple Traffic Lights                               *
*                   Tutorial project 1, example 5                       *
*                                                                       *
*   Lights green, yellow and red lights in sequence (manual operation), *
*   advancing on each pushbutton press                                  *
*                                                                       *
*   Power on (wake from standby) on pushbutton press                    *
*                                                                       *
*   Enters standby mode if no button press                              *
*   during timeout period (10 mins)                                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       GP0 = green  light (LED), active high                           *
*       GP1 = yellow light (LED), active high                           *
*       GP2 = red    light (LED), active high                           *
*       GP3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#include "stdmacros-XC8.h"  // DbnceHi() - debounce switch, wait for high
                            // Requires: TMR0 at 256 us/tick

/***** CONFIGURATION *****/
// int reset, no code protect, no watchdog
#pragma config MCLRE = OFF, CP = OFF, WDTE = OFF

// oscillator frequency for __delay_ms()
#define _XTAL_FREQ  4000000     

// Pin assignments
#define LEDS    GPIO                // all LEDs
#define G_LED   GPIObits.GP0        // individual LEDs
#define Y_LED   GPIObits.GP1
#define R_LED   GPIObits.GP2
#define BUTTON  GPIObits.GP3        // Pushbutton (active low)


/***** CONSTANTS *****/
#define POLL_MS 50                  // polling interval (in ms)
#define TIMEOUT 10                  // auto-off timeout (in minutes)


/***** PROTOTYPES *****/
void standby(void);                 // enter standby (low-power) mode


/***** MAIN PROGRAM *****/
void main()
{
    enum {GREEN, YELLOW, RED} state;    // state = currently-lit LED
    
    uint16_t    time_cnt = 0;       // timeout counter (seconds since reset)
    uint8_t     p_cnt;              // polling loop counter
    
    
    //*** Initialisation
    
    // configure ports
    GPIO = 0b0000;              // start with all LEDs off
    TRIS = 0b1000;              // configure LED pins (GP0-2) as outputs

    // configure wake-on-change, pull-ups and timer
    OPTION = 0b00000111;        // configure wake-up on change and Timer0:
             //0-------             enable wake-up on change (/GPWU = 0)
             //-0------             enable weak pull-ups (/GPPU = 0)
             //--0-----             timer mode (T0CS = 0)
             //----0---             prescaler assigned to Timer0 (PSA = 0)
             //-----111             prescale = 256 (PS = 111)
             //                     -> increment every 256 us
             //                        GP2 usable as an output

    // set initial state
    state = GREEN;              // initial state is green, so
    G_LED = 1;                  // turn on green LED
    
    // wait for stable button release
    // (in case it is still bouncing following wake-up on change)
    DbnceHi(BUTTON); 
    

    //*** Main loop
    for (;;)
    {
        // delay 1 second while polling pushbutton
        // (repeat 1000/POLL_MS times)
        for (p_cnt = 0; p_cnt < 1000/POLL_MS; p_cnt++)  
        {
            __delay_ms(POLL_MS);    // polling interval
        
            // check for button press
            if (!BUTTON)            // if button pressed
            {
                time_cnt = 0;           // reset timeout counter
                
                // light next LED in sequence
                LEDS = 0;               // turn off all LEDs
        
                switch (state)          // next LED depends on currently-lit LED
                {
                    case GREEN:             // if green:
                        state = YELLOW;     //  next state = yellow
                        Y_LED = 1;          //  turn on yellow LED     
                        break;
                
                    case YELLOW:            // if yellow:
                        state = RED;        //  next state = red
                        R_LED = 1;          //  turn on red LED  
                        break;
               
                    case RED:               // if red:
                        state = GREEN;      //  next state = green
                        G_LED = 1;          //  turn on green LED
                        break;
                }
                // wait for stable button release
                DbnceHi(BUTTON);
            }
        }
            
        // check for timeout
        if (++time_cnt == TIMEOUT*60)
            standby();          // enter standby mode
    }                     
}


/***** FUNCTIONS *****/

/***** Enter standby (low power) mode *****/
void standby(void)
{
    LEDS = 0;           // turn off all LEDs
    DbnceHi(BUTTON);    // wait for stable button release
    SLEEP();            // enter sleep mode    
}
