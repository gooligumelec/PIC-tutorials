/************************************************************************
*                                                                       *
*   Filename:      P1C_4-Traffic_lights-manual.c                        *
*   Date:          21/7/13                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Baseline PIC                                         *
*   Processor:     10F200                                               *
*   Compiler:      MPLAB XC8 v1.20 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: stdmacros-XC8.h     (provides DbnceHi macro)        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Simple Traffic Lights                               *
*                   Tutorial project 1, example 4                       *
*                                                                       *
*   Lights green, yellow and red lights in sequence (manual operation), *
*   advancing on each pushbutton press                                  *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       GP0 = green  light (LED), active high                           *
*       GP1 = yellow light (LED), active high                           *
*       GP2 = red    light (LED), active high                           *
*       GP3 = pushbutton switch (active low)                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#include "stdmacros-XC8.h"  // DbnceHi() - debounce switch, wait for high
                            // Requires: TMR0 at 256 us/tick

/***** CONFIGURATION *****/
// int reset, no code protect, no watchdog
#pragma config MCLRE = OFF, CP = OFF, WDTE = OFF

// Pin assignments
#define LEDS    GPIO                // all LEDs
#define G_LED   GPIObits.GP0        // individual LEDs
#define Y_LED   GPIObits.GP1
#define R_LED   GPIObits.GP2
#define BUTTON  GPIObits.GP3        // Pushbutton (active low)


/***** MAIN PROGRAM *****/
void main()
{
    enum {GREEN, YELLOW, RED} state;    // state = currently-lit LED
    
    //*** Initialisation
    
    // configure ports
    GPIO = 0b0000;              // start with all LEDs off
    TRIS = 0b1000;              // configure LED pins (GP0-2) as outputs

    // configure pull-ups and timer
    OPTION = 0b00000111;        // configure wake-up on change and Timer0:
             //-0------             enable weak pull-ups (/GPPU = 0)
             //--0-----             timer mode (T0CS = 0)
             //----0---             prescaler assigned to Timer0 (PSA = 0)
             //-----111             prescale = 256 (PS = 111)
             //                     -> increment every 256 us
             //                        GP2 usable as an output

    // set initial state
    state = GREEN;              // initial state is green, so
    G_LED = 1;                  // turn on green LED
    

    //*** Main loop
    for (;;)
    {
        // wait for button press
        while (BUTTON)              // wait until button low
            ;
                
        // light next LED in sequence
        LEDS = 0;                   // turn off all LEDs
        
        switch (state)              // next LED depends on currently-lit LED
        {
            case GREEN:                 // if green:
                state = YELLOW;         //  next state = yellow
                Y_LED = 1;              //  turn on yellow LED     
                break;
                
            case YELLOW:                // if yellow:
                state = RED;            //  next state = red
                R_LED = 1;              //  turn on red LED  
                break;
               
            case RED:                   // if red:
                state = GREEN;          //  next state = green
                G_LED = 1;              //  turn on green LED
                break;
        }
        
        // wait for stable button release
        DbnceHi(BUTTON);
    }                               // repeat forever
}
