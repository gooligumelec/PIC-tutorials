/************************************************************************
*                                                                       *
*   Filename:      MC_L12-PWM_1f_single-1k_25p.c                        *
*   Date:          17/3/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 1f                               *
*                                                                       *
*   Demonstrates basic single-output PWM (fixed freq and duty cycle)    *
*                                                                       *
*   PWM output is 1 kHz, active-high, 25% duty cycle                    * 
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP1 = PWM output                                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<5);                // configure PORTC as all inputs
                                    //   except RC5 (CCP1 output)
                                        
    // Setup PWM
    // configure Timer2
    T2CONbits.T2CKPS = 0b01;        // prescale = 4 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 4 us
    PR2 = 249;                      // period = 250 x 4 us = 1000 us
                                    //  -> PWM frequency = 1 kHz
    // configure ECCP module
    CCP1CONbits.PM = 0b00;          // select single output mode
                                    //  -> CCP1 active
    CCP1CONbits.DCB = 0b10;         // LSBs of PWM duty cycle = 10
    CCP1CONbits.CCP1M = 0b1100;     // select PWM mode: all active-high                
                                    //  -> single output (CCP1) mode, active-high
    CCPR1L = 62;                    // CCPR1L:DC1B<1:0> = 250 -> pulse width = 250 us                                
                                    //  -> PWM duty cycle = 25%
   
                 
    /*** Main loop ***/  
    for (;;)
    {
        // do nothing
        ;
    } 
}
