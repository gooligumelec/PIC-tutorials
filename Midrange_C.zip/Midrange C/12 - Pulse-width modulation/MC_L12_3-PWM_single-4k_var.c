/************************************************************************
*                                                                       *
*   Filename:      MC_L12_3-PWM_single-4k_var.c                         *
*   Date:          24/3/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 3                                *
*                                                                       *
*   Demonstrates varying single-output PWM duty cycle                   *
*                                                                       *
*   Outputs PWM signal (~3906 Hz) on CCP1                               *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP1 = PWM output (e.g. LED or motor)                           *
*       AN0  = analog input (e.g. pot or LDR)                           *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<5);                // configure PORTC as all inputs
                                    //   except RC5 (CCP1 output)
    ANSEL = 1<<0;                   // make AN0 (only) analog
                                        
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON0bits.VCFG = 0;            // voltage reference is Vdd
    ADCON0bits.CHS = 0b000;         // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // configure Timer2
    T2CONbits.T2CKPS = 0b00;        // prescale = 1 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 1 us
    PR2 = 255;                      // period = 256 x 1 us = 256 us
                                    //  -> PWM frequency = 3906 Hz
    // configure ECCP module
    CCP1CONbits.PM = 0b00;          // select single output mode
                                    //  -> CCP1 active
    CCP1CONbits.DCB = 0b00;         // LSBs of PWM duty cycle = 00
    CCP1CONbits.CCP1M = 0b1100;     // select PWM mode: all active-high                
                                    //  -> single output (CCP1) mode, active-high

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;          // start conversion
        while (ADCON0bits.nDONE)    // wait until done
            ;

        // set new PWM duty cycle
        CCPR1L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
