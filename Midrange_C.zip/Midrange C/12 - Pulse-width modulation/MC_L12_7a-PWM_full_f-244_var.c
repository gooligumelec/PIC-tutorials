/************************************************************************
*                                                                       *
*   Filename:      MC_L12_7a-PWM_full_f-244_var.c                       *
*   Date:          13/3/13                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 12, example 7a                               *
*                                                                       *
*   Demonstrates full-bridge forward PWM mode,                          *
*   with variable duty cycle                                            *
*                                                                       *
*   Outputs PWM signals (~244 Hz) on P1A-D in full-bridge forward mode  *
*   with duty cycle derived from an analog input                        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       P1A  = active (low) output                                      *
*       P1B  = inactive (low) output                                    *
*       P1C  = inactive (high) output                                   *
*       P1D  = modulated PWM output (active high)                       *
*       AN0  = analog input (e.g. pot or LDR)                           *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0b000011;               // configure PORTC as all inputs
                                    //   except RC2-5 (P1A-D outputs)
    ANSEL = 1<<0;                   // make AN0 (only) analog
                                        
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON0bits.VCFG = 0;            // voltage reference is Vdd
    ADCON0bits.CHS = 0b000;         // select channel AN0
    ADCON0bits.ADON = 1;            // turn ADC on

    // Setup PWM
    // configure Timer2
    T2CONbits.T2CKPS1 = 1;          // prescale = 16 
    T2CONbits.TMR2ON = 1;           // enable timer
                                    //  -> TMR2 increments every 16 us
    PR2 = 255;                      // period = 256 x 16 us = 4096 us
                                    //  -> PWM frequency = 244 Hz
    // configure ECCP module
    CCP1CONbits.PM = 0b01;          // select full-bridge output forward mode
                                    //  -> PID modulated, P1A active, P1B, PIC inactive
    CCP1CONbits.DCB = 0b00;         // LSBs of PWM duty cycle = 00
    CCP1CONbits.CCP1M = 0b1110;     // select PWM mode: P1A, P1C active-low
                                    //                  P1B, P1D active-high                
                                    //  -> full-bridge output forward mode,
                                    //      P1D modulated (active-high)
                                    //      P1A active (low)
                                    //      P1B inactive (low)
                                    //      P1C inactive (high)

                 
    /*** Main loop ***/  
    for (;;)
    {
        // sample analog input
        ADCON0bits.GO = 1;          // start conversion
        while (ADCON0bits.nDONE)    // wait until done
            ;
            
        // set new PWM duty cycle
        CCPR1L = ADRESH;            // PWM duty cycle = high byte of ADC result / 256
    } 
}
