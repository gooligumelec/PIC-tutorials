/************************************************************************
*                                                                       *
*   Filename:      MC_L11-ADC_hex-out-CCP.c                             *
*   Date:          9/11/12                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.11 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 7                                *
*                                                                       *
*   Demonstrates use of CCP compare mode special event trigger          *
*   to schedule periodic ADC measurements                               *
*                                                                       *
*   Displays ADC output in hexadecimal on 7-segment LED displays        *
*                                                                       *
*   Regularly samples analog input, using CCP special event trigger,    *
*   displaying result as 2 x hex digits on multiplexed 7-seg displays   *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = digit 1 enable (active high)                  *
*       RA5             = digit 2 (ones) enable                         *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF

// Pin assignments
#define sDIG1_EN    sPORTC.RC5          // digit 1 (most significant) enable (shadow)
#define sDIG2_EN    sPORTA.RA5          // digit 2 (least significant) enable
    

/***** CONSTANTS *****/
#define ADCPeriod   10000               // ADC sample period in microseconds
                                        //   (max 65535)


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display (shadow)


/***** GLOBAL VARIABLES *****/
volatile union {                    // shadow copy of PORTA
    uint8_t         RA;
    struct {
        unsigned    RA0     : 1;
        unsigned    RA1     : 1;
        unsigned    RA2     : 1;
        unsigned    RA3     : 1;
        unsigned    RA4     : 1;
        unsigned    RA5     : 1;
    };
} sPORTA;

volatile union {                    // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSEL = 1<<2;                   // make AN2 (only) analog
    CMCON0bits.CM = 7;              // disable comparators (mode 7) 
    
    // configure Timer0
    OPTION_REGbits.T0CS = 0;        // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    //  -> increment every 8 us
                                    //  -> TMR0 overflows every 2.048 ms    
    INTCONbits.T0IE = 1;            // enable Timer0 interrupt                                  

    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 1 us
                                                                            
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 0;            // MSB of result in ADRESH<7>
    ADCON0bits.VCFG = 0;            // voltage reference is Vdd
    ADCON0bits.CHS = 0b010;         // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on
    PIE1bits.ADIE = 1;              // enable ADC interrupt 
             
    // initialise ECCP module
    CCPR1 = ADCPeriod;              // compare vslue = ADC sample period)
    CCP1CONbits.CCP1M = 0b1011;     // special trigger mode
                                    //  -> sample ADC and reset TMR1 on match
    PIE1bits.CCP1IE = 1;            // enable CCP1 interrupt

    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral interrupts
    ei();                           // enable global interrupts    
    
            
    /*** Main loop ***/
    for (;;)
        ;                           // do nothing
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
                                        // current ADC result (in hex):
    static uint8_t  dig1 = 0;           //   digit 1 (most significant)
    static uint8_t  dig2 = 0;           //   digit 2 (least significant)    
    
    // Service all triggered interrupt sources
    
    if (INTCONbits.T0IF)
    {
        // *** Service Timer0 interrupt
        //
        //  TMR0 overflows every 2.048 ms
        //
        //  Displays current ADC result (in hex) on 7-segment displays
        //
        INTCONbits.T0IF = 0;                    // clear interrupt flag
    
        // Display current ADC result (in hex) on 2 x 7-segment displays
        //   mpx_cnt determines current digit to diplay
        //
        switch (mpx_cnt)
        {
            case 0:
                // display digit 1
                set7seg(dig1);                  // output digit 1  
                sDIG1_EN = 1;                   // enable digit 1 display
                break;
                
            case 1:
                // display digit 2
                set7seg(dig2);                  // output digit 2  
                sDIG2_EN = 1;                   // enable digit 2 display
                break;
        }
        // Increment mpx_cnt, to select next digit for next time
        mpx_cnt++;
        if (mpx_cnt == 2)       // reset count if at end of digit sequence
            mpx_cnt = 0;
            
        // copy shadow regs to ports        
        PORTA = sPORTA.RA;      
        PORTC = sPORTC.RC;  
    }  
    
    if (PIR1bits.ADIF)
    {
        // *** Service ADC interrupt
        //
        //  Conversion is initiated by CCP special event trigger,
        //  every ADCPeriod microseconds
        //
        PIR1bits.ADIF = 0;                      // clear interrupt flag
        
        // copy ADC result to display variables
        //  (to be displayed by Timer0 handler)
        dig1 = ADRESH >> 4;     // get digit 1 from high nybble of ADRESH        
        dig2 = ADRESH & 0x0F;   // get digit 2 from low nybble of ADRESH
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display (shadow) *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011,   // 9 
        0b010011,   // A
        0b010011,   // b
        0b010010,   // C
        0b010001,   // d
        0b010011,   // E
        0b010011    // F           
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to shadow registers
    sPORTA.RA = pat7segA[digit];     
    sPORTC.RC = pat7segC[digit];
}