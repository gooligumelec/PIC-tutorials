/************************************************************************
*                                                                       *
*   Filename:      MC_L11-flash_LED-50p-CCP_int.c                       *
*   Date:          8/11/12                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.11 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 5                                *
*                                                                       *
*   Demonstrates use of CCP compare mode interrupts                     *
*                                                                       *
*   Flashes an LED at 1 Hz, with 50% duty cycle                         *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC3 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF

// Pin assignments
#define sF_LED  sPORTC.RC3              // flashing LED (shadow)


/***** CONSTANTS *****/
#define FlashMS     500                 // LED flash toggle time in milliseconds
                                        //   (max 524 ms)
#define IncCCPR     FlashMS*1000/8      // Amount to increment CCPR1 by to generate
                                        //   FlashMS delay (assuming 8 us/tick)


/***** GLOBAL VARIABLES *****/
volatile union {                        // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTC = 0;                      // start with PORTC clear (LED off)
    sPORTC.RC = 0;                  //   and update shadow
    TRISC = ~(1<<3);                // configure RC3 (only) as an output
                                    
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b11;        // prescale = 8 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 8 us

    // initialise ECCP module
    CCPR1 = IncCCPR;                // load initial compare time
    CCP1CONbits.CCP1M = 0b0010;     // compare mode, interrupt only
    PIE1bits.CCP1IE = 1;            // enable CCP1 interrupt

    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral interrupts
    ei();                           // enable global interrupts    
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // copy shadow register (updated by ISR) to port    
        PORTC = sPORTC.RC;
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    //*** Service CCP1 interrupt
    //
    //  Triggered when TMR1 matches CCPR1
    //      (every 500 ms)
    //
    //  Flashes LED at 1 Hz by toggling on each interrupt
    //
    //  (only CCP1 interrupts are enabled)   
    //   
    PIR1bits.CCP1IF = 0;        // clear interrupt flag
    
    // add offset to CCPR1 for next match
    CCPR1 += IncCCPR;  
    
    // toggle LED (using shadow register) 
    sF_LED = !sF_LED;    
}