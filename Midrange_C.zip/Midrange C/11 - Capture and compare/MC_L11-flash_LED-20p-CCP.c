/************************************************************************
*                                                                       *
*   Filename:      MC_L11-flash_LED-20p-CCP.c                           *
*   Date:          8/11/12                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.11 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 4b                               *
*                                                                       *
*   Demonstrates use of CCP compare mode                                *
*   to generate high and low pulses on the CCP1 pin                     *
*                                                                       *
*   Flashes an LED on CCP1 at 1 Hz, with 20% duty cycle                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP1 = indicator LED                                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<5);                // configure PORTC as all inputs
                                    //   except RC5 (CCP1 output)
                                    
    // configure oscillator
    OSCCONbits.IOSCF = 0b101;       // internal oscillator = 2 MHz 
                                          
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b11;        // prescale = 8 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 16 us

    // initialise ECCP module
    CCPR1 = 0;                      // initial compare time = 0
                                    // (note: CCP initially off, CCP1 output low)
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Output low for 0.8 sec
        
        // add 0.8 sec to last compare time        
        CCPR1 += 800000/16;             // add 0.8 sec / 16 us/count  
        
        // configure ECCP to set CCP1 after 0.8 sec       
        CCP1CONbits.CCP1M = 0b1000;     // compare mode, set CCP1 on match
        
        // wait for CCP match
        PIR1bits.CCP1IF = 0;        // clear CCP1 interrupt flag       
        while (!PIR1bits.CCP1IF)    // wait for flag to go high
            ;
            
            
        // Output high for 0.2 sec
        
        // add 0.2 sec to last compare time        
        CCPR1 += 200000/16;             // add 0.2 sec / 16 us/count  
        
        // configure ECCP to clear CCP1 after 0.2 sec       
        CCP1CONbits.CCP1M = 0b1001;     // compare mode, clear CCP1 on match
        
        // wait for CCP match
        PIR1bits.CCP1IF = 0;        // clear CCP1 interrupt flag       
        while (!PIR1bits.CCP1IF)    // wait for flag to go high
            ;
    } 
}
