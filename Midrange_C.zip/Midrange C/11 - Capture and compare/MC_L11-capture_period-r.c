/************************************************************************
*                                                                       *
*   Filename:      MC_L11-capture_period-r.c                            *
*   Date:          3/11/12                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.11 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 1b                               *
*                                                                       *
*   Demonstrates use of CCP capture mode                                *
*   to measure the period of a digital signal on CCP1,                  *
*   scaled and displayed as a single hex digit                          *
*                                                                       *
*   Period (in 0.5 us) between rising edges on CCP1 is captured         *
*   Result is divided by 1024 and displayed in hex on a single-digit    *
*   7-segment LED display.                                              *
*   Time base is internal RC oscillator at 8 MHz.                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       CCP1         = signal to measure period of (8 ms max)           *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    uint16_t    ccpr1_s = 0;        // saved value of CCPR1 (previous capture)
    
    /*** Initialisation ***/
    
    // configure ports
    PORTA = 0;                      // start with PORTA and PORTC clear 
    PORTC = 0;                      //   (all LED segments off)
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 1<<5;                   //   except RC5 (CCP1 input) 
    ANSEL = 0;                      // no analog inputs            
  
    // configure oscillator
    OSCCONbits.IOSCF = 0b111;       // internal oscillator = 8 MHz 
      
    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 0.5 us

    // configure ECCP module
    CCP1CONbits.CCP1M = 0b0101;     // capture every rising edge
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Measure period of pulses on CCP1 input

        // wait for capture event 
        while (!PIR1bits.CCP1IF)    // wait for CCP1 interrupt flag to go high
            ;
        PIR1bits.CCP1IF = 0;        // clear flag for next event

        // calculate and display scaled period        
        set7seg((CCPR1 - ccpr1_s)/1024 & 0x0f); // period = current capture - saved 
        
        // save current capture time for next period 
        ccpr1_s = CCPR1;
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011,   // 9
        0b000111,   // A
        0b000111,   // b
        0b000110,   // C
        0b000101,   // d
        0b000111,   // E
        0b000111    // F 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to port registers
    PORTA = pat7segA[digit];     
    PORTC = pat7segC[digit];
}