/************************************************************************
*                                                                       *
*   Filename:      MC_L11-flash_LED-50p-CCP.c                           *
*   Date:          7/11/12                                              *
*   File Version:  1.0                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.11 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 11, example 4a                               *
*                                                                       *
*   Demonstrates use of CCP compare mode                                *
*   to toggle the CCP1 pin                                              *
*                                                                       *
*   Flashes an LED on CCP1 at 1 Hz, with 50% duty cycle                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       CCP1 = indicator LED                                            *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int 4 MHz oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = ~(1<<5);                // configure PORTC as all inputs
                                    //   except RC5 (CCP1 output)
                                    
    // initialise Timer1
    TMR1 = 0;                       // clear timer
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b11;        // prescale = 8 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 8 us

    // initialise ECCP module
    CCPR1 = 500000/8;               // initial compare time = 0.5 s /8 us/count
    CCP1CONbits.CCP1M = 0b0010;     // compare mode, toggle CCP1 on match
                                    // (CCP1 initially low)
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Toggle CCP1 output every 0.5 sec

        // wait for CCP match
        PIR1bits.CCP1IF = 0;        // clear CCP1 interrupt flag       
        while (!PIR1bits.CCP1IF)    // wait for flag to go high
            ;

        // add 0.5 sec to last compare time        
        CCPR1 += 500000/8;          // add 0.5 sec / 8 us/count 
    } 
}
