/************************************************************************
*                                                                       *
*   Filename:      MC_L13_1b-EEPROM_read-m.c                            *
*   Date:          20/5/13                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.12 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 13, example 1b                               *
*                                                                       *
*   Demonstrates use of __EEPROM_DATA() macro to declare EEPROM data    *
*   and EEPROM read operations, using EEPROM_READ() macro               *
*                                                                       *
*   Configuration data stored in EEPROM is displayed on 3-digit         *
*   7-segment LED display:                                              *
*       "configuration value" in address 0 is displayed as              *
*           2 x hex digits ("tens" in digits 1, "ones" in digit 2)      *
*       "hardware revision" (A-F) in address 1 is displayed as          *
*           1 x hex digit (digit 3)                                     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*       RC5              = digit 1 enable (active high)                 *
*       RA5              = digit 2 enable                               *
*       RC0              = digit 3 enable                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect
#pragma config MCLRE = ON, CP = OFF, CPD = OFF, BOREN = OFF 
//  no watchdog, power-up timer enabled, int oscillator with I/O
#pragma config WDTE = OFF, PWRTE = ON, FOSC = INTOSCIO
//  no failsafe clock monitor, two-speed start-up disabled 
#pragma config FCMEN = OFF, IESO = OFF

// Pin assignments
#define sDIG1   sPORTC.RC5  // digit 1 enable (shadow)
#define sDIG2   sPORTA.RA5  // digit 2 enable
#define sDIG3   sPORTC.RC0  // digit 3 enable


/***** EEPROM DATA *****/

// config data addresses
#define ee_CFG_VAL  0       // configuration value
#define ee_HW_REV   1       // hardware revision

// initial EEPROM data
__EEPROM_DATA(
    // configuration value
    0x23,                   // (single-byte)
    // hardware revision
    0x0E,                   // (single hex digit, A-F)
    0, 0, 0, 0, 0, 0);
   

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);    // display digit on 7-segment display
                                //  (using shadow regs)


/***** GLOBAL VARIABLES *****/
volatile union {                    // shadow copy of PORTA
    uint8_t         RA;
    struct {
        unsigned    RA0     : 1;
        unsigned    RA1     : 1;
        unsigned    RA2     : 1;
        unsigned    RA3     : 1;
        unsigned    RA4     : 1;
        unsigned    RA5     : 1;
    };
} sPORTA;

volatile union {                    // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;

uint8_t     digit1, digit2, digit3; // display variables (displayed by ISR)


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t config_val;             // configuration value (read from EEPROM)
    uint8_t hw_rev;                 // hardware revision (read from EEPROM)
    
    /*** Initialisation ***/
    
    // configure ports
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;
    
    // configure Timer0
    OPTION_REGbits.T0CS = 0;        // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    //  -> increment every 8 us
                                    //  -> TMR0 overflows every 2.048 ms
                                    
    // Read config data from EEPROM
    //
    // read and display configuration value
    config_val = EEPROM_READ(ee_CFG_VAL);   // get config value
    digit2 = config_val & 0x0F;     // extract ones digit and display in digit 2
    digit1 = config_val >> 4;       // extract "tens" and display in digit 1
    //
    // read and display hardware revision    
    hw_rev = EEPROM_READ(ee_HW_REV);        // get hardware revision value
    digit3 = hw_rev & 0x0F;         // display it in digit 3 (masked to ensure 0-F range)
    
    // enable interrupts
    INTCONbits.T0IE = 1;            // enable Timer0 interrupt
    ei();                           // enable global interrupts
    
            
    /*** Main loop ***/  
    for (;;)
    {
        // do nothing
        ;
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
    
    // *** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2.048 ms
    //
    //  Displays current count on 7-segment displays
    //
    //  (only Timer0 interrupts are enabled)
    //
    INTCONbits.T0IF = 0;            // clear interrupt flag
    
    // Display current count on 3 x 7-segment displays
    //   mpx_cnt determines current digit to diplay
    //
    switch (mpx_cnt)
    {
        case 0: 
            set7seg(digit1);                // output ones digit  
            sDIG1 = 1;                      // enable ones display
            break;
        case 1:
            set7seg(digit2);                // output tens digit  
            sDIG2 = 1;                      // enable tens display
            break;
        case 2:
            set7seg(digit3);                // output minutes digit
            sDIG3 = 1;                      // enable minutes display
            break;
    }
    // Increment mpx_cnt, to select next digit for next time
    mpx_cnt++;
    if (mpx_cnt == 3)       // reset count if at end of digit sequence
        mpx_cnt = 0;
            
    // Copy shadow regs to ports  
    PORTA = sPORTA.RA;             
    PORTC = sPORTC.RC;    
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display (using shadow regs) *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011,   // 9 
        0b010011,   // A
        0b010011,   // b
        0b010010,   // C
        0b010001,   // d
        0b010011,   // E
        0b010011    // F           
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to shadow registers
    sPORTA.RA = pat7segA[digit];     
    sPORTC.RC = pat7segC[digit];
}


