/************************************************************************
*                                                                       *
*   Filename:      MC_L8-ADC_hex-out_direct-HTC.c                       *
*   Date:          23/7/12                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 8, example 3c                                *
*                                                                       *
*   Displays ADC output in hexadecimal on 7-segment LED displays        *
*                                                                       *
*   Continuously samples analog input,                                  *
*   displaying result as 3 x hex digits on multiplexed 7-seg displays   *
*   (ADC result accessed directly within ISR, no display variables)     *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = "hundreds" digit enable (active high)         *
*       RA5             = "tens" digit enable                           *
*       RC0             = ones digit enable                             *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sHUNDREDS_EN    sPORTC.RC5      // "hundreds" enable (shadow)
#define sTENS_EN        sPORTA.RA5      // "tens" enable
#define sONES_EN        sPORTC.RC0      // ones enable
    

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display (shadow)


/***** GLOBAL VARIABLES *****/
volatile union {                    // shadow copy of PORTA
    uint8_t         RA;
    struct {
        unsigned    RA0     : 1;
        unsigned    RA1     : 1;
        unsigned    RA2     : 1;
        unsigned    RA3     : 1;
        unsigned    RA4     : 1;
        unsigned    RA5     : 1;
    };
} sPORTA;

volatile union {                    // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSEL = 1<<2;                   // make AN2 (only) analog
    CMCON0bits.CM = 7;              // disable comparators (mode 7)
    
    // configure Timer0
    OPTION_REGbits.T0CS = 0;        // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    //  -> increment every 8 us
                                    //  -> TMR0 overflows every 2.048 ms    
                                    
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 1;            // LSB of result in ADRESL<0>
    ADCON0bits.VCFG = 0;            // voltage reference is Vdd
    ADCON0bits.CHS = 0b010;         // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on

    // enable interrupts
    INTCONbits.T0IE = 1;            // enable Timer0 interrupt
    ei();                           // enable global interrupts
    
            
    /*** Main loop ***/
    for (;;)
    {
        // sample analog input
        __delay_us(10);             // wait 10 us (acquisition time)
        ADCON0bits.GO = 1;          // start conversion
        while (ADCON0bits.nDONE)    // wait until done
            ;
    }      
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  mpx_cnt = 0;        // multiplex counter
    
    // *** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2.048 ms
    //
    //  Displays current ADC result (in hex) on 7-segment displays
    //
    //  (only Timer0 interrupts are enabled)
    //
    INTCONbits.T0IF = 0;                // clear interrupt flag
    
    // Display current ADC result (in hex) on 3 x 7-segment displays
    //   mpx_cnt determines current digit to display
    //
    switch (mpx_cnt)
    {
        case 0: 
            set7seg(ADRESL & 0x0F);         // output low nybble of ADRESL  
            sONES_EN = 1;                   // enable ones display
            break;
        case 1:
            set7seg(ADRESL >> 4);           // output high nybble of ADRESL  
            sTENS_EN = 1;                   // enable "tens" display
            break;
        case 2:
            set7seg(ADRESH);                // output ADRESH
            sHUNDREDS_EN = 1;               // enable "hundreds" display
            break;
    }
    // Increment mpx_cnt, to select next digit for next time
    mpx_cnt++;
    if (mpx_cnt == 3)       // reset count if at end of digit sequence
        mpx_cnt = 0;
            
    // copy shadow regs to ports        
    PORTA = sPORTA.RA;    
    PORTC = sPORTC.RC;    
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display (shadow) *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011,   // 9 
        0b010011,   // A
        0b010011,   // b
        0b010010,   // C
        0b010001,   // d
        0b010011,   // E
        0b010011    // F           
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to shadow registers
    sPORTA.RA = pat7segA[digit];     
    sPORTC.RC = pat7segC[digit];
}