/************************************************************************
*                                                                       *
*   Filename:      MC_L8-ADC_avg-HTC.c                                  *
*   Date:          24/7/12                                              *
*   File Version:  1.7                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Midrange PIC                                         *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 8, example 7                                 *
*                                                                       *
*   Displays smoothed ADC output in decimal on 2x7-segment LED displays *
*                                                                       *
*   Continuously samples analog input, averages last 16 samples,        *
*   scales result to 0 - 99 and displays as 2 x decimal digits          *
*   on multiplexed 7-seg displays                                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN2             = voltage to be measured (e.g. pot or LDR)      *
*       RA0-1,RA4,RC1-4 = 7-segment display bus (common cathode)        *
*       RC5             = tens digit enable (active high)               *
*       RA5             = ones digit enable                             *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sTENS_EN    sPORTC.RC5      // tens enable (shadow)
#define sONES_EN    sPORTA.RA5      // ones enable


/***** CONSTANTS *****/
#define NSAMPLES    16         // size of sample array


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display (shadow)


/***** GLOBAL VARIABLES *****/
volatile union {                    // shadow copy of PORTA
    uint8_t         RA;
    struct {
        unsigned    RA0     : 1;
        unsigned    RA1     : 1;
        unsigned    RA2     : 1;
        unsigned    RA3     : 1;
        unsigned    RA4     : 1;
        unsigned    RA5     : 1;
    };
} sPORTA;

volatile union {                    // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;

                            // current result in decimal (displayed by ISR):
uint8_t     tens = 0;       //  tens
uint8_t     ones = 0;       //  ones


/***** MAIN PROGRAM *****/
void main()
{
    // Initialisation
    
    // configure ports
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<2;                   //   except RA2/AN2
    ANSEL = 1<<2;                   // make AN2 (only) analog
    CMCON0bits.CM = 7;              // disable comparators (mode 7)
    
    // configure Timer0
    OPTION_REGbits.T0CS = 0;        // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b011;      // prescale = 16
                                    //  -> increment every 16 us
                                    //  -> TMR0 overflows every 4.096 ms    
                                    
    // configure ADC     
    ADCON1bits.ADCS = 0b001;        // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 1;            // LSB of result in ADRESL<0> 
    ADCON0bits.VCFG = 0;            // voltage reference is Vdd
    ADCON0bits.CHS = 0b010;         // select channel AN2
    ADCON0bits.ADON = 1;            // turn ADC on
             

    // enable interrupts
    PIR1bits.ADIF = 0;              // clear ADC interrupt flag
    PIE1bits.ADIE = 1;              // enable ADC
    INTCONbits.T0IE = 1;            //        Timer0
    INTCONbits.PEIE = 1;            //        peripheral 
    ei();                           // and    global interrupts
    
            
    /*** Main loop ***/
    for (;;)
    {
        ;                           // do nothing
    }
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // variables used by timer0 interrupt
    static uint8_t  mpx_cnt = 0;        // multiplex counter
    
    // variables used by ADC interrupt to calculate moving average
    static uint16_t     smp_buf[NSAMPLES];  // sample buffer
                                            //  (cleared by startup code)
    static uint8_t      s = 0;              // index into sample array
    static uint16_t     adc_sum = 0;        // sum of samples in buffer
    uint8_t             adc_dec;            // scaled average ADC output (0-99)
    
    
    // Service all triggered interrupt sources
    
    if (INTCONbits.T0IF)
    {
        // *** Service Timer0 interrupt
        //
        //  TMR0 overflows every 4.096 ms
        //
        //  Displays averaged ADC result (in dec) on 7-segment displays
        //
        //  Initiates next analog conversion
        //
        INTCONbits.T0IF = 0;                    // clear interrupt flag
    
        // Display current averaged ADC result (in dec) on 2 x 7-segment displays
        //   mpx_cnt determines current digit to display
        //
        switch (mpx_cnt)
        {
        case 0: 
            // display ones digit
            set7seg(ones);                  // output ones digit  
            sONES_EN = 1;                   // enable ones display
            break;
            
        case 1:
            // display tens digit
            set7seg(tens);                  // output tens digit  
            sTENS_EN = 1;                   // enable tens display
            break;
        }
        // Increment mpx_cnt, to select next digit for next time
        mpx_cnt++;
        if (mpx_cnt == 2)       // reset count if at end of digit sequence
            mpx_cnt = 0;
        
        // Initiate next analog-to-digital conversion
        ADCON0bits.GO = 1;    
        
        // Copy shadow regs to ports            
        PORTA = sPORTA.RA;        
        PORTC = sPORTC.RC;            
    }  
    
    if (PIR1bits.ADIF)
    {
        // *** Service ADC interrupt
        //
        //  Conversion is initiated by Timer0 interrupt, every 4 ms
        //
        //  Updates moving average with each ADC result
        //
        PIR1bits.ADIF = 0;                      // clear interrupt flag
        
        // store current ADC result and update running total
        adc_sum -= smp_buf[s];              // subtract old sample from running total
        smp_buf[s] = ADRESH<<8 | ADRESL;    // save new sample
        adc_sum += smp_buf[s];              // and add it to running total
        
        // advance index to reference next sample
        if (++s == NSAMPLES) s = 0;
        
        // scale running total to 0-99 for display
        adc_dec = (uint32_t)adc_sum * 100 / (1024 * NSAMPLES);
        
        // extract digits of scaled result for Timer0 handler to display
        ones = (unsigned)adc_dec%10;   
        tens = (unsigned)adc_dec/10;  
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display (shadow) *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011    // 9 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    }; 
    
    // lookup pattern bits and write to shadow registers
    sPORTA.RA = pat7segA[digit];     
    sPORTC.RC = pat7segC[digit];
}