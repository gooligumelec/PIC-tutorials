/************************************************************************
*                                                                       *
*   Filename:      MC_L8-ADC_4LEDs-HTC.c                                *
*   Date:          18/7/12                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 8, example 1                                 *
*                                                                       *
*   Demonstrates basic use of ADC                                       *
*                                                                       *
*   Continuously samples analog input, copying value to 4 x LEDs        *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       AN0     = voltage to be measured (e.g. pot output or LDR)       *
*       RC0-3   = output LEDs (RC3 is MSB)                              *
*                                                                       *
************************************************************************/

#include <xc.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/ 
    
    // configure ports
    TRISC = 0;                  // PORTC is all outputs
    ANSEL = 1<<0;               // AN0 (only) is analog
    CMCON0bits.CM = 7;          // disable comparators (mode 7) 
    
    // configure ADC     
    ADCON1bits.ADCS = 0b001;    // Tad = 8*Tosc = 2.0 us (with Fosc = 4 MHz) 
    ADCON0bits.ADFM = 0;        // MSB of result in ADRESH<7>
    ADCON0bits.VCFG = 0;        // voltage reference is Vdd
    ADCON0bits.CHS = 0b000;     // select channel AN0
    ADCON0bits.ADON = 1;        // turn ADC on

    
    /*** Main loop ***/
    for (;;)
    {
        // sample analog input
        __delay_us(10);             // wait 10 us (acquisition time)
        ADCON0bits.GO = 1;          // start conversion
        while (ADCON0bits.nDONE)    // wait until done
            ;
        
        // display result on 4 x LEDs
        PORTC = ADRESH >> 4;    // copy high four bits of result
                                //   to low nybble of output port (LEDs)
    }
}
