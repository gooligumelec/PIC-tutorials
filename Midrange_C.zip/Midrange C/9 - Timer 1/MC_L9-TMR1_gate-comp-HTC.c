/************************************************************************
*                                                                       *
*   Filename:      MC_L9-TMR1_gate-comp-HTC                             *
*   Date:          31/7/12                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 7                                 *
*                                                                       *
*   Demonstrates use of Timer1 gate control                             *
*   to measure the pulse width of an analog signal on C2IN+,            *
*   scaled and displayed as a single hex digit                          *
*                                                                       *
*   Timer1 is used to time (in microseconds) every high pulse on /T1G.  *
*   Result is divided by 256 and displayed in hex on a single-digit     *
*   7-segment LED display.                                              *
*   Time base is internal RC oscillator.                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       C2IN+        = analog signal to measure pulse width of          *
*                      (active high, 4 ms max)                          *    
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);
         

/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTA = 0;                      // start with PORTA and PORTC clear 
    PORTC = 0;                      //   (all LED segments off)
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0b000001;               //   except C2IN+ input (RC0) 

    // configure voltage reference 
    VRCONbits.VRR = 1;              // select low range
    VRCONbits.VR = 12;              //   CVref = 0.5 x Vdd
    VRCONbits.VREN = 1;             // enable voltage reference
                                    //  -> CVref = 2.5 V, if Vdd = 5.0 V  
                                      
    // configure comparators 
    CMCON0bits.CIS = 1;      
    CMCON0bits.CM = 0b010;          // select mode 2:
                                    //   C2 +ref is CVref,
                                    //   C2 -ref is C2IN+ (with CIS = 1),
                                    //   no external outputs,
                                    //   both comparators on
    CMCON0bits.C2INV = 1;           // C2 output inverted
                                    //  -> C2OUT = 1 if C2IN+ > CVref 
    CMCON1bits.C2SYNC = 1;          //  sync C2OUT with TMR1
    
    // configure Timer1
    T1CONbits.TMR1GE = 1;           // gate enabled
    T1CONbits.T1GINV = 1;           // gate is active high
    CMCON1bits.T1GSS = 0;           // gate source is C2OUT
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 1 us,
                                    //     gated by C2OUT (active high)
           
                 
    /*** Main loop ***/   
    for (;;)
    {
        // Measure width of pulses on C2IN+ input
        // (assume C2 output is low at start of loop)
        
        // clear Timer1
        TMR1 = 0; 
        
        // wait for one full high pulse 
        while (!CMCON0bits.C2OUT)   // wait for C2OUT to go high
            ;
        while (CMCON0bits.C2OUT)    // wait for C2OUT to go low
            ;   
        
        // display scaled Timer1 count (divide by 256)         
        set7seg(TMR1/256 & 0x0f);    // display low nybble of TMR1/256
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011,   // 9
        0b000111,   // A
        0b000111,   // b
        0b000110,   // C
        0b000101,   // d
        0b000111,   // E
        0b000111    // F 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to port registers
    PORTA = pat7segA[digit];     
    PORTC = pat7segC[digit];
}