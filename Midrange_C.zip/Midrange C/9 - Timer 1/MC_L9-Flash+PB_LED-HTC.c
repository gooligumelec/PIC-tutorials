/************************************************************************
*                                                                       *
*   Filename:      MC_L9-Flash+PB_LED-HTC                               *
*   Date:          27/7/12                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Midrange PIC                                         *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 1                                 *
*                                                                       *
*   Demonstrates use of Timer1 to maintain timing of background actions *
*   while performing other actions in response to changing inputs       *
*                                                                       *
*   One LED simply flashes at 1 Hz (50% duty cycle).                    *
*   The other LED is only lit when the pushbutton is pressed            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0 = "button pressed" indicator LED                            *
*       RC1 = flashing LED                                              *
*       RA3 = pushbutton (active low)                                   *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_OFF & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sB_LED  sPORTC.RC0      // "button pressed" indicator LED (shadow)
#define sF_LED  sPORTC.RC1      // flashing LED (shadow)
#define BUTTON  PORTAbits.RA3   // pushbutton (active low)


/***** CONSTANTS *****/
#define FlashMS 500                     // LED flash toggle time in milliseconds
#define InitT1  65536-FlashMS*1000/8    // Initial value to load into TMR1 to generate
                                        //   FlashMS delay (assuming 8 us/tick)

/***** GLOBAL VARIABLES *****/
union {                                 // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTC = 0;                      // start with PORTC clear (all LEDs off)
    sPORTC.RC = 0;                  //   and update shadow
    TRISC = 0;                      // configure all PORTC pins as outputs
    
    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // select timer mode          
    T1CONbits.T1CKPS = 0b11;        // prescale = 8 
                                    //  -> increment TMR1 every 8 us
    PIR1bits.TMR1IF = 0;            //  clear overflow flag  
    
                 
    /*** Main loop ***/
    for (;;)
    {
        // delay ~500ms while responding to button press
        T1CONbits.TMR1ON = 0;       // stop Timer1
        TMR1 = InitT1;              // load TMR1 with initial value (InitT1)
                                    //   to generate 500 ms count 
        T1CONbits.TMR1ON = 1;       // start Timer1
        
        while (!PIR1bits.TMR1IF)    // repeat until Timer1 overflows (500 ms)
        {
            sB_LED = !BUTTON;           // turn on indicator only if button pressed

            PORTC = sPORTC.RC;          // copy shadow register to port 
        }  
        PIR1bits.TMR1IF = 0;        // clear overflow flag for next time

        // toggle flashing LED
        sF_LED = !sF_LED;                              
    } 
}
