/************************************************************************
*                                                                       *
*   Filename:      MC_L9-Count_7seg_x1-HTC                              *
*   Date:          31/7/12                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 4                                 *
*                                                                       *
*   Demonstrates use of Timer1 LP oscillator and interrupt              *
*   to implement a single-digit seconds counter,                        *
*   shown on a 7-segment LED display                                    *
*                                                                       *
*   Single digit 7-segment LED display counts repeating 0 -> 9          *
*   1 count per second, with timing derived from 32.768 kHz crystal     *
*   driven by Timer1 oscillator                                         *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       OSC1, OSC2   = 32.768 kHz crystal                               *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** GLOBAL VARIABLES *****/
volatile uint8_t    t1_secs = 0;    // seconds count (even only),
                                    //   updated by Timer1 interrupt


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     digit;              // digit to display
    
    /*** Initialisation ***/
    
    // configure ports
    PORTA = 0;                      // start with PORTA and PORTC clear 
    PORTC = 0;                      //   (all LED segments off)
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;     
    
    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 1;          // LP oscillator enabled 
    T1CONbits.TMR1CS = 1;           // external clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
                                    //  -> increment TMR1 at 32.768 kHz
                                    
    T1CONbits.TMR1ON = 0;           // stop Timer1                                    
    TMR1 = 0;                  	    // clear TMR1 (start counting from 0)
    T1CONbits.TMR1ON = 1;           // start Timer1
    PIE1bits.TMR1IE = 1;            // enable Timer1 interrupt

    
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts     
           
                 
    /*** Main loop ***/ 
    for (;;)
    {
        // calculate digit to display
        digit = t1_secs;            // get seconds count (even only) 
                                    //   (maintained by Timer1 interrupt)
        if (TMR1 & 1<<15)           // if TMR1<15> is set, we are in an odd second
            ++digit;                //   so add one to display digit
                                        
        // display current seconds count
        set7seg(digit);             // output digit
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // *** Service Timer1 interrupt
    //
    //  TMR1 overflows every 2 s 
    //
    //  Handles background time keeping:
    //  Each interrupt advances current count by 2 secs    
    //
    //  (only Timer1 interrupts are enabled)
    //
    PIR1bits.TMR1IF = 0;            // clear interrupt flag
    
    // increment seconds count by 2
    t1_secs += 2;
    if (t1_secs == 10)          // when count reaches 10, 
        t1_secs = 0;            //   reset it to 0
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011    // 9
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    }; 
    
    // lookup pattern bits and write to port registers
    PORTA = pat7segA[digit];     
    PORTC = pat7segC[digit];
}