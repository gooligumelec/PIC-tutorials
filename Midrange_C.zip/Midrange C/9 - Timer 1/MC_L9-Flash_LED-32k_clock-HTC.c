/************************************************************************
*                                                                       *
*   Filename:      MC_L9-Flash_LED-32k_clock-HTC                        *
*   Date:          31/7/12                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *                 
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 3                                 *
*                                                                       *
*   Demonstrates basic use of Timer1 LP oscillator                      *
*                                                                       *
*   LED flashes at 1 Hz (50% duty cycle), with timing derived           *
*   from 32.768 kHz crystal driven by Timer1 oscillator                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0        = flashing LED                                       *
*       OSC1, OSC2 = 32.768 kHz crystal                                 *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sF_LED  sPORTC.RC0              // flashing LED (shadow)


/***** GLOBAL VARIABLES *****/
union {                                 // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTC = 0;                      // start with PORTC clear (all LEDs off)
    sPORTC.RC = 0;                  //   and update shadow
    TRISC = 0;                      // configure all PORTC pins as outputs
    
    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 1;          // LP oscillator enabled 
    T1CONbits.TMR1CS = 1;           // external clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
    T1CONbits.TMR1ON = 1;           // start Timer1    
                                    //  -> increment TMR1 at 32.768 kHz
                 
    /*** Main loop ***/
    for (;;)
    {
        // TMR1<14> cycles at 1 Hz, so continually copy to LED
        sF_LED = (TMR1 & 1<<14) != 0;    // sF_LED = TMR1<14>        
            
        // copy shadow register to port    
        PORTC = sPORTC.RC;
    } 
}
