/************************************************************************
*                                                                       *
*   Filename:      MC_L9-Flash+PB_LED-int-HTC                           *
*   Date:          29/7/11                                              *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 2                                 *
*                                                                       *
*   Demonstrates use of Timer1 interrupt to perform a background task   *
*   while main loop performs other actions                              *
*                                                                       *
*   One LED flashes at approx 1 Hz (50% duty cycle).                    *
*   The other LED is only lit when the pushbutton is pressed            *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0 = "button pressed" indicator LED                            *
*       RC1 = flashing LED                                              *
*       RA3 = pushbutton (active low)                                   *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  int reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_OFF & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sB_LED  sPORTC.RC0      // "button pressed" indicator LED (shadow)
#define sF_LED  sPORTC.RC1      // flashing LED (shadow)
#define BUTTON  PORTAbits.RA3   // pushbutton (active low)


/***** CONSTANTS *****/
#define FlashMS 500                     // LED flash toggle time in milliseconds
#define InitT1  65536-FlashMS*1000/8    // Initial value to load into TMR1 to generate
                                        //   FlashMS delay (assuming 8 us/tick)

/***** GLOBAL VARIABLES *****/
volatile union {                        // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTC = 0;                      // start with PORTC clear (all LEDs off)
    sPORTC.RC = 0;                  //   and update shadow
    TRISC = 0;                      // configure all PORTC pins as outputs
    
    // configure Timer1
    T1CONbits.TMR1GE = 0;           // gate disabled
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // select timer mode          
    T1CONbits.T1CKPS = 0b11;        // prescale = 8 
                                    //  -> increment TMR1 every 8 us
    T1CONbits.TMR1ON = 0;           // stop Timer1                                    
    TMR1 = InitT1;                  // load TMR1 with initial value (InitT1)
                                    //   to overflow after 500 ms     
    T1CONbits.TMR1ON = 1;           // start Timer1   
    PIE1bits.TMR1IE = 1;            // enable Timer1 interrupt
    
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts    
           
                 
    /*** Main loop ***/
    for (;;)
    {
        // respond to button press
        di();                       // (disable interrupts while updating shadow register)
            sB_LED = !BUTTON;           // turn on indicator only if button pressed
        ei();
            
        // copy shadow register (updated by ISR) to port    
        PORTC = sPORTC.RC;
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // *** Service Timer1 interrupt
    //
    //  TMR1 overflows every 500 ms (approx)
    //
    //  Flashes LED at ~1 Hz by toggling on each interrupt
    //      (every ~500 ms)    
    //
    //  (only Timer1 interrupts are enabled)
    //
    PIR1bits.TMR1IF = 0;            // clear interrupt flag
    
    // add offset to Timer1 for overflow after 500 ms
    T1CONbits.TMR1ON = 0;           // stop Timer1  
    TMR1 += InitT1+1;               // add 16-bit offset (initial value 
                                    //  adjusted for addition overhead) to TMR1
                                    //  to generate ~500 ms count
    T1CONbits.TMR1ON = 1;           // start Timer1

    // toggle flashing LED
    sF_LED = !sF_LED; 
}
