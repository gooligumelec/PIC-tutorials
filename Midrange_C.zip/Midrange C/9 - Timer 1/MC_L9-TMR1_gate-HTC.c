/************************************************************************
*                                                                       *
*   Filename:      MC_L9-TMR1_gate-HTC                                  *
*   Date:          31/7/12                                              *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 9, example 6                                 *
*                                                                       *
*   Demonstrates use of Timer1 gate control                             *
*   to measure the pulse width of a digital signal on /T1G,             *
*   scaled and displayed as a single hex digit                          *
*                                                                       *
*   Timer1 is used to time (in microseconds) every high pulse on /T1G.  *
*   Result is divided by 256 and displayed in hex on a single-digit     *
*   7-segment LED display.                                              *
*   Time base is internal RC oscillator.                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-2, RC1-4 = 7-segment display bus (common cathode)           *
*       /T1G         = signal to measure pulse width of                 *
*                      (active high, 4 ms max)                          *    
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define T1G     PORTAbits.RA4       // Timer1 gate input (configured as active high)


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);        // display digit on 7-segment display


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTA = 0;                      // start with PORTA and PORTC clear 
    PORTC = 0;                      //   (all LED segments off)
    TRISC = 0;                      // configure PORTA and PORTC as all outputs
    TRISA = 1<<4;                   //   except RA4 (/T1G input) 
    ANSEL = 0;                      // no analog inputs            
    
    // configure Timer1
    T1CONbits.TMR1GE = 1;           // gate enabled
    T1CONbits.T1GINV = 1;           // gate is active high
    CMCON1bits.T1GSS = 1;           // gate source is /T1G
    T1CONbits.T1OSCEN = 0;          // LP oscillator disabled 
    T1CONbits.TMR1CS = 0;           // internal clock          
    T1CONbits.T1CKPS = 0b00;        // prescale = 1 
    T1CONbits.TMR1ON = 1;           // enable timer
                                    //  -> increment TMR1 every 1 us,
                                    //     gated by active high on /T1G
           
                 
    /*** Main loop ***/  
    for (;;)
    {
        // Measure width of pulses on /T1G input
        // (assume /T1G is low at start of loop)
        
        // clear Timer1
        TMR1 = 0;              
        
        // wait for one full high pulse 
        while (!T1G)                // wait for T1G to go high
            ;
        while (T1G)                 // wait for T1G to go low
            ;   
        
        // display scaled Timer1 count (divide by 256)         
        set7seg(TMR1/256 & 0x0f);    // display low nybble of TMR1/256
    } 
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[16] = {
        // RA2:0 = EFG
        0b000110,   // 0
        0b000000,   // 1
        0b000101,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b000111,   // 6
        0b000000,   // 7
        0b000111,   // 8
        0b000011,   // 9
        0b000111,   // A
        0b000111,   // b
        0b000110,   // C
        0b000101,   // d
        0b000111,   // E
        0b000111    // F 
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[16] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110,   // 9
        0b010110,   // A
        0b011000,   // b
        0b001010,   // C
        0b011100,   // d
        0b001010,   // E
        0b000010    // F        
    }; 
    
    // lookup pattern bits and write to port registers
    PORTA = pat7segA[digit];     
    PORTC = pat7segC[digit];
}