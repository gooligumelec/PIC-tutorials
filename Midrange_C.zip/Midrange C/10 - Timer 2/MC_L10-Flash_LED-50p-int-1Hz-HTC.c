/************************************************************************
*                                                                       *
*   Filename:      MC_L10-Flash_LED-50p-int-1Hz-HTC.c                   *
*   Date:          1/8/12                                               *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 10, example 1                                *
*                                                                       *
*   Demonstrates use of Timer2 to perform generate a specific time-base *
*   for an interrupt-driven background task                             *
*                                                                       *
*   Flash an LED at exactly 1 Hz (50% duty cycle).                      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RC0 = flashing LED                                              *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sF_LED  sPORTC.RC0              // flashing LED (shadow)


/***** CONSTANTS *****/
#define FlashMS     500                 // LED flash toggle time in milliseconds


/***** GLOBAL VARIABLES *****/
volatile union {                        // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    PORTC = 0;                      // start with PORTC clear (LED off)
    sPORTC.RC = 0;                  //   and update shadow
    TRISC = 0b111110;               // configure RC0 (only) as an output
    
    // configure Timer2
    PR2 = 249;                      // Timer2 period = 250 clocks (PR2 = period-1)
    T2CONbits.T2CKPS = 1;           // prescale = 4
    T2CONbits.TOUTPS = 9;           // postscale = 10
                                    //  -> increment TMR2 every 4 us,
                                    //     match PR2 every  = 1 ms (4 us x 250)
                                    //     set TMR2IF every 10 ms (1 ms x 10)
    T2CONbits.TMR2ON = 1;           // enable Timer2
    PIE1bits.TMR2IE = 1;            // enable Timer2 interrupt    
          
    // enable interrupts
    INTCONbits.PEIE = 1;            // enable peripheral 
    ei();                           //   and global interrupts  

                                    
    /*** Main loop ***/
    for (;;)
    {
        // copy shadow register (updated by ISR) to port    
        PORTC = sPORTC.RC;
    } 
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    static uint8_t  cnt_10ms = 0;   // counts 10 ms periods
    
    // *** Service Timer2 interrupt
    //
    //  Runs every 10 ms
    //    (every 10th TMR2/PR2 match;
    //     TMR2 matches PR2 every 250 x 4 clocks = 1000 us)
    //
    //  Flashes LED at 1 Hz 
    //    by toggling on every 50th interrupt (every 500 ms)  
    //
    //  (only Timer2 interrupts are enabled)
    //
    PIR1bits.TMR2IF = 0;            // clear interrupt flag
    
    // toggle LED every 500 ms
    ++cnt_10ms;                     // increment 10 ms period count
    if (cnt_10ms == FlashMS/10)     // if we've counted for 500 ms,
    {     
        cnt_10ms = 0;               //   reset count
        sF_LED = !sF_LED;           //   toggle LED (using shadow register)
    }
}
