/************************************************************************
*                                                                       *
*   Filename:      MC_L7-Count_7seg_x1-HTC.c                            *
*   Date:          3/7/12                                               *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 1a                                *
*                                                                       *
*   Demonstrates use of lookup tables to drive a 7-segment display      *
*                                                                       *
*   Single digit 7-segment display counts repeating 0 -> 9              *
*   1 second per count, with timing derived from int RC oscillator      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);


/***** LOOKUP TABLES *****/

// pattern table for 7 segment display on port A
const uint8_t pat7segA[10] = {
    // RA4 = E, RA1:0 = FG
    0b010010,   // 0
    0b000000,   // 1
    0b010001,   // 2
    0b000001,   // 3
    0b000011,   // 4
    0b000011,   // 5
    0b010011,   // 6
    0b000000,   // 7
    0b010011,   // 8
    0b000011    // 9    
}; 

// pattern table for 7 segment display on port C
const uint8_t pat7segC[10] = {
    // RC4:1 = CDBA
    0b011110,   // 0
    0b010100,   // 1
    0b001110,   // 2
    0b011110,   // 3
    0b010100,   // 4
    0b011010,   // 5
    0b011010,   // 6
    0b010110,   // 7
    0b011110,   // 8
    0b011110    // 9
};  


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     digit;              // digit to be displayed

    
    /*** Initialisation ***/ 
    
    // configure ports    
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;


    /*** Main loop ***/        
    for (;;)
    {
        // display each digit from 0 to 9 for 1 sec
        for (digit = 0; digit < 10; digit++)
        {
            // display digit
            PORTA = pat7segA[digit];    // lookup port A and C patterns
            PORTC = pat7segC[digit];
        
            // delay 1 sec
            __delay_ms(1000);
        }  
    }      
}
