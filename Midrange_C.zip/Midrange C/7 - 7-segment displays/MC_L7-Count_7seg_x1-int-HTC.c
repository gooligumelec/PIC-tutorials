/************************************************************************
*                                                                       *
*   Filename:      MC_L7-Count_7seg_x1-int-HTC.c                        *
*   Date:          3/7/12                                               *
*   File Version:  1.2                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 2a                                *
*                                                                       *
*   Demonstrates use of a timer-based interrupt                         *
*   to update a single 7-segment display                                *
*                                                                       *
*   Single digit 7-segment display counts repeating 0 -> 9              *
*   1 second per count, with timing derived from int RC oscillator      *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*       RC0              = display enable (active high)                 *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);

// Pin assignments
#define sDISPLAY    sPORTC.RC0  // display enable (shadow)


/***** PROTOTYPES *****/
void set7seg(uint8_t digit);    // display digit on 7-segment display
                                //  (using shadow regs)


/***** GLOBAL VARIABLES *****/
volatile union {                    // shadow copy of PORTA
    uint8_t         RA;
    struct {
        unsigned    RA0     : 1;
        unsigned    RA1     : 1;
        unsigned    RA2     : 1;
        unsigned    RA3     : 1;
        unsigned    RA4     : 1;
        unsigned    RA5     : 1;
    };
} sPORTA;

volatile union {                    // shadow copy of PORTC
    uint8_t         RC;
    struct {
        unsigned    RC0     : 1;
        unsigned    RC1     : 1;
        unsigned    RC2     : 1;
        unsigned    RC3     : 1;
        unsigned    RC4     : 1;
        unsigned    RC5     : 1;
    };
} sPORTC;

uint8_t     digit = 0;              // digit to be displayed by ISR


/***** MAIN PROGRAM *****/
void main()
{
    /*** Initialisation ***/
    
    // configure ports
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;
    
    // configure Timer0
    OPTION_REGbits.T0CS = 0;        // select timer mode
    OPTION_REGbits.PSA = 0;         // assign prescaler to Timer0
    OPTION_REGbits.PS = 0b010;      // prescale = 8
                                    //  -> increment every 8 us
                                    //  -> TMR0 overflows every 2.048 ms
                                    
    // enable interrupts
    INTCONbits.T0IE = 1;            // enable Timer0 interrupt
    ei();                           // enable global interrupts
    
            
    /*** Main loop ***/
    for (;;)
    {
        // display each digit from 0 to 9 for 1 sec
        for (digit = 0; digit < 10; digit++)
        {
            __delay_ms(1000);           // delay 1 sec
        }  
    }      
}


/***** INTERRUPT SERVICE ROUTINE *****/
void interrupt isr(void)
{
    // *** Service Timer0 interrupt
    //
    //  TMR0 overflows every 2.048 ms
    //
    //  Displays single digit on 7-segment display
    //
    //  (only Timer0 interrupts are enabled)
    //
    INTCONbits.T0IF = 0;            // clear interrupt flag
    
    // display digit (using shadow registers)
    set7seg(digit);                 // output digit
    sDISPLAY = 1;                   // enable display
    
    // copy shadow regs to ports        
    PORTA = sPORTA.RA;             
    PORTC = sPORTC.RC;    
}


/***** FUNCTIONS *****/

/***** Display digit on 7-segment display (using shadow regs) *****/
void set7seg(uint8_t digit)
{
    // pattern table for 7 segment display on port A
    const uint8_t pat7segA[10] = {
        // RA4 = E, RA1:0 = FG
        0b010010,   // 0
        0b000000,   // 1
        0b010001,   // 2
        0b000001,   // 3
        0b000011,   // 4
        0b000011,   // 5
        0b010011,   // 6
        0b000000,   // 7
        0b010011,   // 8
        0b000011    // 9    
    }; 

    // pattern table for 7 segment display on port C
    const uint8_t pat7segC[10] = {
        // RC4:1 = CDBA
        0b011110,   // 0
        0b010100,   // 1
        0b001110,   // 2
        0b011110,   // 3
        0b010100,   // 4
        0b011010,   // 5
        0b011010,   // 6
        0b010110,   // 7
        0b011110,   // 8
        0b011110    // 9
    };   
    
    // lookup pattern bits and write to shadow registers
    sPORTA.RA = pat7segA[digit];     
    sPORTC.RC = pat7segC[digit];
}