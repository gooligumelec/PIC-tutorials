/************************************************************************
*                                                                       *
*   Filename:      MC_L7-Count_7seg_x1-single-HTC.c                     *
*   Date:          3/7/12                                               *
*   File Version:  1.1                                                  *
*                                                                       *
*   Author:        David Meiklejohn                                     *
*   Company:       Gooligum Electronics                                 *
*                                                                       *
*************************************************************************
*                                                                       *
*   Architecture:  Mid-range PIC                                        *
*   Processor:     16F684                                               *
*   Compiler:      MPLAB XC8 v1.01 (Free mode)                          *
*                                                                       *
*************************************************************************
*                                                                       *
*   Files required: none                                                *
*                                                                       *
*************************************************************************
*                                                                       *
*   Description:    Lesson 7, example 1b                                *
*                                                                       *
*   Demonstrates use of lookup tables to drive a 7-segment display      *
*                                                                       *
*   Single digit 7-segment display counts repeating 0 -> 9              *
*   1 second per count, with timing derived from int RC oscillator      *
*   (single pattern lookup array)                                       *
*                                                                       *
*************************************************************************
*                                                                       *
*   Pin assignments:                                                    *
*       RA0-1,RA4, RC1-4 = 7-segment display bus (common cathode)       *
*                                                                       *
************************************************************************/

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ   4000000    // oscillator frequency for _delay()


/***** CONFIGURATION *****/
//  ext reset, no code or data protect, no brownout detect, 
//  no watchdog, power-up timer enabled, int clock with I/O,
//  no failsafe clock monitor, two-speed start-up disabled 
__CONFIG(MCLRE_ON & CP_OFF & CPD_OFF & BOREN_OFF & 
         WDTE_OFF & PWRTE_ON & FOSC_INTOSCIO &
         FCMEN_OFF & IESO_OFF);


/***** LOOKUP TABLES *****/

// pattern table for 7 segment display on ports A and C
const uint8_t pat7seg[10] = {
    // RC4:1,RA4,RA1:0 = CDBAEFG
    0b1111110,  // 0
    0b1010000,  // 1
    0b0111101,  // 2
    0b1111001,  // 3
    0b1010011,  // 4
    0b1101011,  // 5
    0b1101111,  // 6
    0b1011000,  // 7
    0b1111111,  // 8
    0b1111011   // 9
}; 


/***** MAIN PROGRAM *****/
void main()
{
    uint8_t     digit;              // digit to be displayed

    
    /*** Initialisation ***/ 
    
    // configure ports   
    TRISA = 0;                      // configure PORTA and PORTC as all outputs
    TRISC = 0;

        
    /*** Main loop ***/ 
    for (;;)
    {
        // display each digit from 0 to 9 for 1 sec
        for (digit = 0; digit < 10; digit++)
        {
            // display digit by extracting pattern bits for all pins
            PORTA = (pat7seg[digit] & 1<<2) << 2 |      // RA4 
                    (pat7seg[digit] & 0b00000011);      // RA0-1  
            PORTC = (pat7seg[digit] >> 2) & 0b011110;   // RC1-4  
        
            // delay 1 sec
            __delay_ms(1000);
        }  
    }      
}
